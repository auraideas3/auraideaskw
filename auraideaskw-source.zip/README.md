# منصة أورا للأفكار للاستشارات الأكاديمية والدراسات العليا
### Aura Ideas Academic Advisory & Postgraduate Research Platform

منصة ويب متكاملة وعصرية ثنائية اللغة (العربية والإنجليزية) مخصصة لمؤسسة **أورا للأفكار (Aura Ideas)** للاستشارات الأكاديمية وخدمات طلبة الماجستير والدكتوراه والباحثين في دولة الكويت ودول الخليج العربي.

---

## 🌟 مميزات المنصة (Key Features)

- **دعم كامل للغتين (العربية والانجليزية)** مع ضبط تلقائي للاتجاه (RTL / LTR).
- **تصميم واجهة أكاديمية فاخرة** متوافقة مع جميع الأجهزة (Mobile, Tablet, Desktop) ومبنية باستخدام Tailwind CSS.
- **محاكي جودة الأبحاث وفحص الاستلال والأصالة العلمي** التفاعلي.
- **دليل أنظمة التوثيق العلمي المعتمدة** (APA 7th, Harvard, MLA 9th, Chicago/Turabian, IEEE).
- **استعراض التخصصات والكليات الأكاديمية** لطلبة الماجستير والدكتوراه.
- **خريطة طريق الإنجاز المنهجي (5-Step Roadmap)** من بلورة الفكرة وحتى الاستعداد للمناقشة.
- **نظام الحجز والاستشارة والتواصل الفوري عبر واتساب** مع كود مخصص لكل طلب.
- **توافق كامل مع لوائح عمادات الدراسات العليا** في الجامعات الكويتية والخليجية.

---

## 🛠️ التقنيات المستخدمة (Tech Stack)

- **React 19**
- **Vite 6**
- **TypeScript**
- **Tailwind CSS v4**
- **Lucide Icons**

---

## 🚀 التشغيل المحلي (Getting Started Locally)

### 1. تثبيت الحزم (Install Dependencies)
```bash
npm install
```

### 2. تشغيل خادم التطوير (Run Development Server)
```bash
npm run dev
```
افتح المتصفح على: `http://localhost:3000`

### 3. بناء المشروع للإنتاج (Build for Production)
```bash
npm run build
```
سيتم إنشاء ملفات الموقع الجاهزة للنشر في مجلد `dist/`.

---

## 📤 كيفية رفع المشروع إلى GitHub (How to Push to GitHub)

### الطريقة الأولى: مباشرة عبر واجهة AI Studio (موصى بها)
1. في واجهة **Google AI Studio Build** الحالية، انقر على القائمة العلوية أو الإعدادات (**⚙️ Settings** أو **`...`**).
2. اختر **Export to GitHub**.
3. قم باختيار المستودع: `auraideas3/auraideaskw`.
4. اضغط **Export** وسيتم نقل كامل الكود تلقائياً.

---

### الطريقة الثانية: عبر سطر الأوامر (Git CLI)
إذا قمت بتنزيل ملف المشروع مضغوطاً (`Download ZIP`) من قائمة AI Studio إلى جهازك:

1. فك ضغط المجلد وافتحه في سطر الأوامر (Terminal أو Git Bash).
2. نفذ الأوامر التالية المجهزة خصيصاً لمستودعك:

```bash
# 1. تهيئة المستودع
git init

# 2. إضافة كافة ملفات المشروع
git add .

# 3. حفظ النسخة
git commit -m "feat: initial commit for Aura Ideas Academic Platform"

# 4. تعيين الفرع الرئيسي
git branch -M main

# 5. ربط المستودع الخاص بك
git remote add origin https://github.com/auraideas3/auraideaskw.git

# 6. رفع الأكواد (سيطلب منك اسم المستخدم و Personal Access Token الخاص بـ GitHub)
git push -u origin main
```
> **ملاحظة لكلمة المرور**: عند طلب كلمة المرور في Git، استخدم **Personal Access Token (Classic or Fine-grained)** من إعدادات GitHub (Settings -> Developer Settings -> Personal access tokens) بصلاحية `repo`.

---

## 🌐 النشر المجاني (Deployment Options)
بعد رفع المشروع على GitHub، يمكنك نشره بضغطة زر مجاناً على:
- **Vercel**: قم باستيراد مستودع GitHub وسيقوم باكتشاف Vite ونشر الموقع فورياً.
- **Netlify**: يدعم مشاريع Vite React تلقائياً.
- **GitHub Pages**: من خلال إضافة GitHub Action لنشر مجلد `dist/`.

---

## 📄 الترخيص (License)
جميع الحقوق محفوظة لمؤسسة أورا للأفكار © 2026.
