import { 
  StatItem, 
  ValueItem, 
  FacultyField, 
  CitationStandard, 
  RoadmapStep, 
  UniversityPartner, 
  Testimonial, 
  FaqItem 
} from '../types';

export const contentData = {
  ar: {
    nav: {
      brand: "أورا للأفكار",
      subBrand: "للاستشارات والخدمات الأكاديمية",
      about: "عن المؤسسة",
      visionMission: "الرؤية والرسالة",
      values: "قيمنا ومعاييرنا",
      standards: "معايير التوثيق",
      disciplines: "التخصصات الأكاديمية",
      process: "خريطة العمل",
      qualityCheck: "فحص الاستلال والجودة",
      universities: "الجامعات المعتمدة",
      faq: "الأسئلة الشائعة",
      contact: "تواصل معنا",
      requestConsultation: "طلب استشارة مجانية",
      quickCall: "خط الاستشارات المباشر",
      kuwaitOffice: "الكويت والخليج العربي",
      whatsapp: "محادثة واتساب فورية"
    },
    hero: {
      tag: "الصرح الأكاديمي الاستشاري الأول في دولة الكويت ودول الخليج",
      titleStart: "نُضيء مسارك الأكاديمي نحو",
      titleHighlight: "الريادة والتميز البحثي",
      subtitle: "في «أورا للأفكار»، نكرس خبرات نخبة من أساتذة الجامعات وحملة الدكتوراه لتقديم استشارات بحثية دقيقة، وتوجيه منهجي رصين لطلبة الدراسات العليا (ماجستير ودكتوراه) وفق لوائح الجامعات الكويتية والدولية وبأعلى درجات النزاهة العلمية.",
      ctaPrimary: "احجز استشارة أكاديمية متخصصة",
      ctaSecondary: "تعرف على منهجية عملنا",
      guarantees: [
        "100% ضمان أصالة علمية وعدم استلال",
        "تقارير فحص الاستلال الرسمية المعتمدة مع كل تسليم",
        "متابعة دورية حتى إجازة البحث والمناقشة",
        "سرية تامة وعقود حماية الملكية الفكرية"
      ]
    },
    stats: [
      {
        number: "+12",
        label: "عاماً من الخبرة",
        description: "في دعم مسيرة الباحثين وطلبة الدراسات العليا في الخليج",
        icon: "Award"
      },
      {
        number: "+2,850",
        label: "رسالة وبحث مُجاز",
        description: "أطروحة ماجستير ودكتوراه وأبحاث ترقية قُبلت بامتياز",
        icon: "BookOpenCheck"
      },
      {
        number: "+65",
        label: "مستشاراً أكاديمياً",
        description: "من حملة الدكتوراه والأساتذة المشاركين في شتى التخصصات",
        icon: "Users"
      },
      {
        number: "0%",
        label: "نسبة انتحال أو استلال",
        description: "التزام صارم بفحص الاقتباس المعتمد عالمياً",
        icon: "ShieldCheck"
      }
    ] as StatItem[],
    aboutStory: {
      badge: "قصتنا وتأسيسنا",
      title: "لماذا وُجدت «أورا للأفكار»؟",
      p1: "انطلقت «أورا للأفكار» من حاجة ملحّة في الميدان الأكاديمي الكويتي والخليجي: وجود شريك علمي نزيه ومحترف يرتقي بمستوى البحث الأكاديمي، ويتجاوز الممارسات العشوائية والمكاتب غير المؤهلة التي تفتقر للمنهجية الأكاديمية.",
      p2: "نحن في أورا نؤمن بأن البحث العلمي رسالة حضارية تستلزم الدقة، والتحليل الممنهج، والامتثال الصارم للوائح عمادات الدراسات العليا في الجامعات العريقة مثل جامعة الكويت، وجامعة الخليج للعلوم والتكنولوجيا (GUST)، والجامعة الأمريكية في الشرق الأوسط (AUM)، والجامعات المعتمدة في المملكة المتحدة والولايات المتحدة ومصر والأردن.",
      p3: "فلسفتنا لا تقوم على التكليف المكتبي المجهول، بل على 'التوجيه والإرشاد الأكاديمي الرصين' (Academic Mentoring & Coaching)؛ حيث نمكّن الباحث من امتلاك أدوات بحثه، وفهم تحليلاته الإحصائية، وصياغة فجوة بحثه بمنتهى الثقة أمام لجان المناقشة والحكم.",
      pillars: [
        {
          title: "التأطير المنهجي السليم",
          desc: "بناء الإشكالية وصياغة الأسئلة والفرضيات وفق مناهج البحث العلمية المقننة."
        },
        {
          title: "النزاهة الأكاديمية المطلقة",
          desc: "رفض قاطع للسرقة العلمية أو إعادة الصياغة الآلية المشوهة؛ كتابة أكاديمية بأقلام خبراء."
        },
        {
          title: "التدريب على الدفاع والمناقشة",
          desc: "جلسات محاكاة افتراضية (Mock Viva) لتجهيز الطالب لأسئلة المناقشين والرد العلمي المقنع."
        },
        {
          title: "المواكبة التقنية الذكية",
          desc: "استخدام أحدث برمجيات التحليل النوعي والكمي كـ SPSS و AMOS و SmartPLS و NVivo."
        }
      ]
    },
    visionMission: {
      badge: "البوصلة الاستراتيجية",
      title: "رؤيتنا ورسالتنا ومرتكزاتنا",
      subtitle: "المبادئ التوجيهية التي تقود كل استشارة ومسودة بحثية تصدر عن أورا للأفكار",
      visionTitle: "رؤيتنا (Our Vision)",
      visionDesc: "أن نكون المنارة الأكاديمية الأولى في الشرق الأوسط والمرجع الأكثر ثقة لطلبة الدراسات العليا والباحثين، من خلال ترسيخ ثقافة البحث العلمي الأصيل والمساهمة في نشر المعرفة الإنسانية الرصينة في كبريات المجلات الدولية المصنفة.",
      missionTitle: "رسالتنا (Our Mission)",
      missionDesc: "تمكين الباحثين العرب والأكاديميين في الكويت والخليج من إنجاز أبحاثهم ورسائلهم الجامعية بأعلى مستويات الجودة المنهجية، عبر توفير استشارات علمية متخصصة، وتحليلات إحصائية دقيقة، وتدقيق لغوي رفيع، مع المحافظة التامة على الأمانة العلمية والخصوصية الفردية.",
      values: [
        {
          id: "integrity",
          title: "الأمانة العلمية والنزاهة",
          subtitle: "Academic Integrity",
          description: "نلتزم بنسبة أصالة 100% وخلو تام من الانتحال أو التلفيق البياني، ونقدم تقارير فحص الاقتباس الرسمية المعتمدة عالمياً مع كل مرحلة تسليم.",
          points: ["فحص استلال علمي كامل ومفصل", "توثيق المراجع الأولية والحديثة", "احترام أخلاقيات البحث العلمي IRB"],
          icon: "Shield",
          color: "emerald"
        },
        {
          id: "confidentiality",
          title: "السرية التامة والخصوصية",
          subtitle: "Strict Confidentiality",
          description: "بيانات الباحث ومسودات أفكاره وموضوع أطروحته محمية باتفاقية عدم إفصاح صارمة (NDA). لا نشارك أي مسودة أو معلومة مع أي جهة خارجية.",
          points: ["اتفاقية سرية قانونية ملزمة", "خوادم بيانات مشفرة ومؤمنة", "حذف المسودات المؤقتة بعد الاعتماد"],
          icon: "Lock",
          color: "amber"
        },
        {
          id: "precision",
          title: "الدقة المنهجية والأكاديمية",
          subtitle: "Methodological Rigor",
          description: "صياغة علمية رصينة ومحكمة تتبع الدليل الاسترشادي المعتمد في جامعتك، من تحديد الفجوة البحثية وحتى إقرار التوصيات العلمية القابلة للتطبيق.",
          points: ["توافق كامل مع دليل الجامعة", "تنسيق توثيق دقيق (APA, Harvard)", "مراجعة ثنائية من لجان تدقيق مستقلة"],
          icon: "CheckCircle2",
          color: "blue"
        },
        {
          id: "commitment",
          title: "الالتزام التام بالمواعيد والمراجعة",
          subtitle: "Punctuality & Free Revisions",
          description: "نلتزم بجداول التسليم المرحلية بدقة، ونوفر ضمان التعديل المجاني غير المحدود وفق ملحوظات المشرف الأكاديمي حتى إجازة الرسالة نهائياً.",
          points: ["تسليمات مجدولة متفق عليها مسبقاً", "تعديل مجاني وفق ملاحظات المشرف", "دعم ومتابعة مستمرة على مدار الساعة"],
          icon: "Clock",
          color: "indigo"
        }
      ] as ValueItem[]
    },
    standards: {
      badge: "دليل التوثيق والامتثال",
      title: "المعايير والأنظمة الأكاديمية المعتمدة",
      subtitle: "نلتزم بصرامة بأحدث إصدارات أنظمة التوثيق العالمية المعتمدة في الجامعات الكويتية والدولية",
      citationList: [
        {
          id: "apa7",
          name: "نظام الجمعية الأمريكية النفسية",
          edition: "APA 7th Edition (الإصدار السابع المحدث)",
          primaryFields: "العلوم التربوية، علم النفس، الإدارة والأعمال، التمريض، العلوم الاجتماعية",
          bookExample: {
            inText: "(العتيبي، 2024، ص. 45) / (Al-Otaibi, 2024, p. 45)",
            reference: "العتيبي، ناصر. (2024). استراتيجيات القيادة التربوية في المدارس الكويتية الحديثة (ط. 2). مكتبة الفلاح للنشر والتوزيع."
          },
          journalExample: {
            inText: "(الكندري ومبارك، 2023) / (Al-Kandari & Mubarak, 2023)",
            reference: "الكندري، فاطمة، ومبارك، جاسم. (2023). أثر التحول الرقمي على كفاءة المؤسسات الحكومية في دولة الكويت. المجلة التربوية لجامعة الكويت، 37(146)، 89-122. https://doi.org/10.34120/0080-037-146-003"
          },
          keyRules: [
            "حذف مكان النشر في الإصدار السابع والتركيز على الـ DOI",
            "توثيق حتى 20 مؤلفاً في قائمة المراجع قبل استخدام علامة الحذف",
            "التوثيق المتن لثلاثة مؤلفين فأكثر باستخدام (المؤلف الأول وآخرون) من أول ورود"
          ]
        },
        {
          id: "harvard",
          name: "نظام توثيق هارفارد",
          edition: "Harvard Reference System (UK & GUST standard)",
          primaryFields: "العلوم الاقتصادية، المحاسبة والتمويل، إدارة الموارد البشرية، التسويق",
          bookExample: {
            inText: "(Smith 2023: 112) / (الشمري 2023: 112)",
            reference: "الشمري، فهد (2023) التحليل المالي المتقدم للشركات المدرجة في بورصة الكويت. الكويت: دار الكتب."
          },
          journalExample: {
            inText: "(Al-Mutairi and Brown 2024)",
            reference: "Al-Mutairi, A. and Brown, R. (2024) 'Corporate governance and firm performance in GCC emerging markets', Journal of Financial Regulation and Compliance, 32(2), pp. 210-234."
          },
          keyRules: [
            "تاريخ النشر يوضع دون أقواس في قائمة المراجع أو بأقواس وفق الدليل المحدد",
            "عناوين المقالات بين علامتي تنصيص مفردة ' ' وعنوان المجلة مائل",
            "فصل الصفحات بـ pp. وليس p. فقط"
          ]
        },
        {
          id: "mla9",
          name: "نظام رابطة اللغات الحديثة",
          edition: "MLA 9th Edition (الإصدار التاسع)",
          primaryFields: "الأدب العربي والإنجليزي، الدراسات اللغوية، الترجمة، النقد الأدبي، الفلسفة",
          bookExample: {
            inText: "(الهاجري 78) / (Al-Hajri 78) [بدون فاصلة ولا حرف ص]",
            reference: "الهاجري، عبد الله. جماليات السرد في الرواية الكويتية المعاصرة. المجلس الوطني للثقافة والفنون والآداب، 2022."
          },
          journalExample: {
            inText: "(العوضي 104)",
            reference: "العوضي، سارة. \"تحولات الخطاب الشعري النسوي في الخليج العربي.\" مجلة عالم الفكر، المجلد 51، العدد 3، 2023، ص ص 95-130."
          },
          keyRules: [
            "عدم استخدام الفاصلة بين اسم المؤلف ورقم الصفحة في التوثيق المتن",
            "استخدام عنوان الحاوية (Container) للعناصر الرقمية والدوريات",
            "قائمة الأعمال المستشهد بها تسمى (Works Cited) وتُرتب هجائياً"
          ]
        },
        {
          id: "chicago",
          name: "نظام شيكاغو / تورابيان",
          edition: "Chicago Manual of Style (17th Ed.) / Turabian",
          primaryFields: "التاريخ، القانون، العلوم السياسية والعلاقات الدولية، الدراسات الإسلامية",
          bookExample: {
            inText: "هوامش سفلية رقمية في أسفل كل صفحة: [1] ناصر الدوسري، تطور النظام الدستوري الكويتي، ص 142.",
            reference: "الدوسري، ناصر. تطور النظام الدستوري في دولة الكويت: دراسة مقارنة. الكويت: مؤسسة الكويت للتقدم العلمي، 2021."
          },
          journalExample: {
            inText: "حاشية سفلية: [2] يوسف الصباح، \"السياسة الخارجية لدول مجلس التعاون،\" ص 55.",
            reference: "الصباح، يوسف. \"أولويات الدبلوماسية الإنسانية في السياسة الخارجية الكويتية.\" دراسات الخليج والجزيرة العربية 49، عدد 189 (2023): 45-80."
          },
          keyRules: [
            "نظام الهوامش السفلية التوضيحية والحواشي (Notes and Bibliography)",
            "استخدام صيغة مختصرة للهامش بعد ذكره للمرة الأولى (اسم العائلة، العنوان المختصر، الصفحة)",
            "ترتيب قائمة المراجع النهائية هجائياً مع تقديم اسم العائلة"
          ]
        },
        {
          id: "ieee",
          name: "نظام معهد مهندسي الكهرباء والإلكترونيات",
          edition: "IEEE Standards & Vancouver (Sci/Tech)",
          primaryFields: "علوم الحاسوب، الذكاء الاصطناعي، الهندسة الكهربائية والميكانيكية، العلوم الطبية",
          bookExample: {
            inText: "As demonstrated in [4], the algorithm achieves...",
            reference: "[4] K. Al-Ghanim and M. Peterson, Deep Learning Architectures for IoT Security in Smart Cities, 2nd ed. Piscataway, NJ: IEEE Press, 2023."
          },
          journalExample: {
            inText: "Recent telemetry benchmarks [7], [12] confirm...",
            reference: "[7] A. Al-Azemi, \"Predictive Maintenance in Petroleum Refineries Using Hybrid LSTM Networks,\" IEEE Transactions on Industrial Informatics, vol. 19, no. 8, pp. 8812-8821, Aug. 2023."
          },
          keyRules: [
            "التوثيق بأقواس مربعة ورقم تسلسلي [1]، [2] بحسب ترتيب الورود في المتن",
            "قائمة المراجع مرتبة رقمياً لا هجائياً",
            "اختصار أسماء المجلات العلمية بحسب دليل IEEE المعتمد"
          ]
        }
      ] as CitationStandard[]
    },
    faculties: {
      badge: "الكوادر والاستشارات",
      title: "التخصصات الأكاديمية التي نغطيها",
      subtitle: "نخبة من المستشارين وأساتذة الجامعات في أكثر من 18 حقلاً علمياً دقيقاً",
      items: [
        {
          id: "business",
          name: "العلوم الإدارية والمالية",
          description: "استشارات متقدمة لرسائل الماجستير والدكتوراه في إدارة الأعمال، التسويق الاستراتيجي، التمويل والمصارف الإسلامية، والمحاسبة والمراجعة.",
          icon: "TrendingUp",
          degrees: ["MBA", "MSc Finance", "DBA / PhD"],
          subfields: ["حوكمة الشركات", "التحول الرقمي", "سلاسل الإمداد", "إدارة الموارد البشرية"]
        },
        {
          id: "law",
          name: "العلوم القانونية والشريعة",
          description: "تأطير منهجي رصين للأبحاث القانونية المقارنة، القانون التجاري، القانون الجنائي، التحكيم الدولي، والقوانين الكويتية والخليجية.",
          icon: "Scale",
          degrees: ["LL.M Law", "دكتوراه في القانون العام والخاص"],
          subfields: ["القانون المدني والتجاري", "الجرائم الإلكترونية", "قوانين العمل والتأمين", "الشريعة والقضاء"]
        },
        {
          id: "education",
          name: "العلوم التربوية والمناهج",
          description: "تصميم أدوات البحث التربوي (استبيانات، بطاقات ملاحظة، اختبارات تحصيلية) وفق معايير الصدق والثبات وإحصاء بيرسون وكرونباخ ألفا.",
          icon: "GraduationCap",
          degrees: ["ماجستير التربية M.Ed", "دكتوراه الفلسفة في المناهج"],
          subfields: ["تكنولوجيا التعليم", "القيادة المدرسية", "التربية الخاصة والموهبة", "طرق تدريس اللغة والعلوم"]
        },
        {
          id: "tech",
          name: "الحاسوب والذكاء الاصطناعي",
          description: "صياغة أوراق بحثية ومنهجيات تجريبية في تعلّم الآلة، معالجة اللغات الطبيعية، الأمن السيبراني، وشبكات الحوسبة السحابية.",
          icon: "Cpu",
          degrees: ["MSc Computer Science", "PhD AI & Cyber"],
          subfields: ["نماذج التعلّم العميق", "أمن إنترنت الأشياء", "علم البيانات والتنقيب", "أنظمة الرؤية الحاسوبية"]
        },
        {
          id: "stats",
          name: "التحليل الإحصائي والنمذجة",
          description: "فريق إحصائي متخصص في معالجة البيانات المعقدة وتفسير الجداول، اختبار الفرضيات، ونمذجة المعادلات البنائية SEM بدقة تامة.",
          icon: "BarChart3",
          degrees: ["SPSS & AMOS", "SmartPLS 4", "R & Python Data"],
          subfields: ["تحليل الانحدار الخطي واللوجستي", "التحليل العاملي الاستكشافي والتوكيدي", "اختبارات T-Test و ANOVA", "تحليل المسار Path Analysis"]
        },
        {
          id: "humanities",
          name: "اللغويات والعلوم الإنسانية",
          description: "أبحاث علم الاجتماع، الإعلام والاتصال الرقمي، اللغويات التطبيقية، الترجمة التحريرية والفورية، والنقد الأدبي والفكري.",
          icon: "Languages",
          degrees: ["MA Linguistics", "ماجستير إعلام وعلاقات عامة"],
          subfields: ["تحليل الخطاب النقدي", "علم الاجتماع الأسري", "الإعلام الجديد والهوية", "الترجمة الأكاديمية المحكمة"]
        }
      ] as FacultyField[]
    },
    qualitySimulator: {
      badge: "محاكي الفحص الأكاديمي",
      title: "كيف نضمن جودة وأصالة أبحاثك؟",
      subtitle: "جرب بنفسك محاكي معايير الجودة وفحص الاستلال لمعاينة المعايير الدقيقة التي تطبقها أورا للأفكار",
      tryLabel: "اختر نوع التحقق الأكاديمي:",
      tabs: {
        plagiarism: "فحص الاستلال والسرقة الأدبية المعتمد",
        methodology: "فحص الصرامة المنهجية والفجوة",
        references: "فحص حداثة ودقة المراجع",
        aiDetection: "فحص خلو البحث من الذكاء الاصطناعي المباشر"
      }
    },
    roadmap: {
      badge: "المسار المنهجي",
      title: "خريطة العمل: من الفكرة حتى مناقشة الأطروحة",
      subtitle: "خمس مراحل دقيقة ومجدولة زمنياً تضمن إنجازاً مريحاً ومطابقاً لتعليمات جامعتك",
      steps: [
        {
          step: 1,
          title: "بلورة الفكرة وتحديد الفجوة البحثية",
          duration: "المرحلة الأولى",
          description: "جلسة استشارية أولية لاختيار موضوع حديث وذو قيمة علمية، وتحديد المشكلة والفجوة البحثية (Research Gap) استناداً إلى أحدث أوراق 2022-2025.",
          deliverables: ["صياغة عنوان دقيق ومبتكر", "بيان المشكلة وأهميتها", "خريطة المفاهيم الأولية"]
        },
        {
          step: 2,
          title: "إعداد خطة البحث (Research Proposal)",
          duration: "المرحلة الثانية",
          description: "صياغة بروبوزال أكاديمي متكامل مستوفٍ لكافة الشروط الجامعية: الأهداف، التساؤلات، الفرضيات، الحدود، والمنهجية المقترحة، جاهز لتقديمه للجنة السيمنار.",
          deliverables: ["خطة بحث رسمية معتمدة", "دراسات سابقة استطلاعية", "مخطط فصول الرسالة"]
        },
        {
          step: 3,
          title: "بناء الإطار النظري والدراسات السابقة",
          duration: "المرحلة الثالثة",
          description: "كتابة نقدية مقارنة للأدبيات (Critical Literature Review) خالية من السرد الإنشائي، مع توثيق المراجع بنظام جامعتك المعتمد واستخلاص التعقيب العلمي الرصين.",
          deliverables: ["فصل إطار نظري مؤصل", "مصفوفة الدراسات السابقة", "بيان تميز البحث الحالي"]
        },
        {
          step: 4,
          title: "التصميم المنهجي والتحليل الإحصائي",
          duration: "المرحلة الرابعة",
          description: "تحديد مجتمع وعينة البحث، بناء أدوات الدراسة والتحقق من صدقها وثباتها، ثم تفريغ البيانات وتحليلها ببرامج SPSS أو SmartPLS وتفسير النتائج ومناقشتها.",
          deliverables: ["أداة دراسة مقننة ومحكمة", "جداول إحصائية وتفسير منطقي", "ربط النتائج بالدراسات السابقة"]
        },
        {
          step: 5,
          title: "التدقيق النهائي، الفحص، وتدريب المناقشة (Viva)",
          duration: "المرحلة الخامسة",
          description: "مراجعة لغوية وتنسيقية نهائية، إصدار تقرير فحص الاستلال الرسمي، وجلسة محاكاة افتراضية لتدريب الباحث على سيناريوهات أسئلة المناقشين والرد العلمي.",
          deliverables: ["نسخة مطابقة لدليل الطباعة الجامعي", "تقرير فحص استلال معتمد 0%", "حقيبة أسئلة وتوجيهات المناقشة"]
        }
      ] as RoadmapStep[]
    },
    universities: {
      badge: "الاعتمادات والتوافق",
      title: "الجامعات والهيئات التي نوائم متطلباتها",
      subtitle: "خبرتنا العميقة بلوائح عمادات الدراسات العليا تضمن قبول مسوداتك دون عوائق شكلية",
      list: [
        { name: "جامعة الكويت (Kuwait University)", category: "الجامعة الحكومية الأولى", location: "الشدادية - كيفان", badge: "توافق كامل مع دليل كلية الدراسات العليا" },
        { name: "جامعة الخليج للعلوم والتكنولوجيا (GUST)", category: "جامعة خاصة رائدة", location: "مشرف، الكويت", badge: "تطابق مع معايير هارفارد و APA" },
        { name: "الجامعة الأمريكية في الشرق الأوسط (AUM)", category: "التعليم التكنولوجي والإداري", location: "العقيلة، الكويت", badge: "برامج ماجستير MBA وهندسة" },
        { name: "الهيئة العامة للتعليم التطبيقي (PAAET)", category: "التعليم التطبيقي والتدريب", location: "الشويخ، الكويت", badge: "أبحاث الترقية والدراسات التخصصية" },
        { name: "الجامعة العربية المفتوحة (AOU)", category: "شراكة مع الجامعة البريطانية المفتوحة", location: "العارضية، الكويت", badge: "متطلبات ماجستير التربية والحوسبة" },
        { name: "جامعات المملكة المتحدة والولايات المتحدة", category: "الدراسات الدولية والمبتعثين", location: "بريطانيا وأمريكا", badge: "خدمات لطلبة البعثات والموفدين الكويتيين" }
      ] as UniversityPartner[]
    },
    testimonials: {
      badge: "شهادات نعتز بها",
      title: "ماذا يقول باحثونا في الكويت والخليج؟",
      subtitle: "قصص نجاح حقيقية لأساتذة وباحثين حصلوا على درجات الامتياز وتوصيات بالنشر",
      list: [
        {
          name: "د. مشاري الهاجري",
          degree: "دكتوراه في إدارة الموارد البشرية",
          university: "باحث مبتعث في المملكة المتحدة (بريطانيا)",
          faculty: "كلية العلوم الإدارية",
          year: "2024",
          quote: "كنت أواجه معضلة في التحليل الإحصائي لنمذجة المعادلات البنائية عبر SmartPLS. فريق أورا للأفكار لم يقم فقط بمساعدتي في التحليل بدقة متناهية، بل جلس معي المستشار خطوة بخطوة لشرح كل جدول، مما مكّنني من الدفاع عن نتائجي بكل ثقة أمام الممتحنين.",
          rating: 5
        },
        {
          name: "أ. نورة العازمي",
          degree: "ماجستير الإدارة التربوية والقيادة",
          university: "جامعة الكويت - كلية الدراسات العليا",
          faculty: "كلية التربية",
          year: "2024",
          quote: "الالتزام الصارم بدليل التوثيق لجامعة الكويت APA 7th وسرعة التجاوب مع ملاحظات مشرفي كانا استثنائيين. التعديلات تمت بلا أي تكلفة إضافية وتقرير فحص الاستلال كان نظيفاً تماماً بدون أي استلال. أنصح كل طالب دراسات عليا بأورا.",
          rating: 5
        },
        {
          name: "م. عبد العزيز الشمري",
          degree: "ماجستير إدارة الأعمال (MBA)",
          university: "الجامعة الأمريكية في الشرق الأوسط (AUM)",
          faculty: "إدارة الأعمال الدولية",
          year: "2023",
          quote: "السرية التامة والمصداقية العالية هما أكثر ما لمسته في أورا للأفكار. عملت معهم على إعداد بروبوزال الأطروحة ومراجعة الأدبيات، وكانت المراجع حديثة جداً من كبريات قواعد البيانات مثل ScienceDirect و Emerald.",
          rating: 5
        }
      ] as Testimonial[]
    },
    faq: {
      badge: "الوضوح والشفافية",
      title: "الأسئلة الأكثر تكراراً",
      subtitle: "إجابات صريحة عن طبيعة خدماتنا الأكاديمية وضماناتنا",
      items: [
        {
          category: "طبيعة الخدمة",
          question: "هل تقدم أورا للأفكار أبحاثاً جاهزة، أم خدمات استشارية وتوجيهية؟",
          answer: "أورا للأفكار مؤسسة استشارية علمية رصينة تلتزم بـ «التوجيه والإرشاد الأكاديمي» (Academic Mentoring) ولا تقدم أي أعمال مخالفة للنزاهة العلمية. نساعد الباحث في تخطي العقبات المنهجية، صياغة ومراجعة مسوداته، تدقيق المراجع، وتحليل البيانات الإحصائية، مع تمكينه المعرفي الكامل ليكون صاحب البحث الحقيقي القادر على مناقشته واجتيازه بجدارة."
        },
        {
          category: "الجودة والأصالة",
          question: "كيف أضمن عدم وجود سرقة أدبية أو انتحال (Plagiarism) في البحث؟",
          answer: "نمنح كل باحث تقريراً رسمياً مفصلاً من برامج فحص الاستلال العالمية المعتمدة في الجامعات، والذي يثبت خلو المسودة من أي اقتباس غير مشروع وتوثيق كافة المصادر الأولية والثانوية بأحدث أنظمة التوثيق، ونضمن نسبة استلال توافق أو تقل عن النسبة المحددة بلائحة جامعتك."
        },
        {
          category: "الضمان والتعديلات",
          question: "ماذا لو طلب المشرف الأكاديمي أو لجنة التحكيم تعديلات على البحث؟",
          answer: "نلتزم في أورا للأفكار بـ «ضمان التعديلات المجانية الكاملة» وفق ملحوظات المشرف الجامعي ما دامت ضمن إطار الخطة المتفق عليها. لا تنتهي مهمتنا عند تسليم المسودة، بل نرافقك خطوة بخطوة حتى تصدر إجازة البحث الرسمية."
        },
        {
          category: "السرية والخصوصية",
          question: "هل معلوماتي الشخصية وفكرة بحثي مشمولة بالسرية التامة؟",
          answer: "نعم، السرية هي الركيزة الأساسية في ميثاق شرف أورا للأفكار. نلتزم باتفاقية سرية وحماية ملكية فكرية (NDA) تحظر مشاركة فكرة بحثك أو اسمك أو ملفاتك مع أي طرف ثالث تحت أي ظرف، وتُحفظ الملفات على خوادم آمنة ومشفرة."
        },
        {
          category: "المواعيد والدفع",
          question: "كيف يتم تسليم العمل وآلية الدفع؟",
          answer: "نتبع آلية التسليم المرحلي المجزأ (Milestone-based delivery)؛ حيث يتم تقسيم البحث إلى مراحل محددة بتواريخ متفق عليها (مثلاً: خطة البحث، ثم الفصل الأول، ثم الفصل الثاني، وهكذا)، ويطلع الباحث على كل مرحلة ويوافق عليها قبل الانتقال للمرحلة التالية، مع طرق دفع إلكترونية مرنة وآمنة تناسب الباحثين في الكويت والخليج."
        }
      ] as FaqItem[]
    },
    contact: {
      badge: "تواصل مباشر",
      title: "ابدأ رحلتك الأكاديمية بنجاح وثقة",
      subtitle: "تواصل مع مستشارنا الأكاديمي الآن للحصول على تقييم مجاني ومناقشة تفاصيل بحثك",
      hotlineTitle: "الخط الساخن المباشر في الكويت والخليج",
      whatsappCta: "تواصل معنا مباشرة عبر واتساب",
      emailTitle: "البريد الإلكتروني للاستشارات",
      officeTitle: "المقر الرئيسي وخدمات الخليج",
      officeDesc: "دولة الكويت - العاصمة | خدمة مباشرة لكافة الباحثين في الكويت، السعودية، قطر، الإمارات، البحرين، وعمان",
      form: {
        title: "طلب استشارة مجانية وسرية",
        nameLabel: "الاسم الكريم",
        namePlaceholder: "أدخل اسمك الكريم",
        phoneLabel: "رقم الواتساب (مع رمز الدولة)",
        phonePlaceholder: "+965 XXXXXXXX",
        universityLabel: "الجامعة أو الهيئة الأكاديمية",
        universityPlaceholder: "مثال: جامعة الكويت / GUST / AUM / أخرى",
        degreeLabel: "المرحلة الدراسية",
        degrees: ["ماجستير (Master's)", "دكتوراه (PhD)", "بكالوريوس (تخرج)", "بحث ترقية لأعضاء هيئة التدريس", "نشر علمي (Scopus / ISI)"],
        serviceLabel: "نوع الخدمة المطلوبة",
        services: [
          "إعداد خطة بحث متكاملة (Proposal)",
          "مراجعة الأدبيات والإطار النظري",
          "التصميم المنهجي وأدوات الدراسة",
          "التحليل الإحصائي ومناقشة النتائج (SPSS / AMOS)",
          "التدقيق اللغوي والترجمة الأكاديمية",
          "فحص الاستلال وإصدار التقرير الأكاديمي المعتمد",
          "مراجعة شاملة وتعديل وفق تقرير المشرف",
          "تدريب على المناقشة وجلسة السمينار"
        ],
        notesLabel: "تفاصيل أو ملاحظات عن الموضوع",
        notesPlaceholder: "اكتب نبذة عن موضوع بحثك أو التخصص أو الموعد النهائي المتوقع...",
        submitBtn: "إرسال طلب الاستشارة وسيتواصل معك المستشار فوراً",
        secureNote: "🔒 جميع البيانات تعامل بسرية تامة ومحمية بموجب اتفاقية حماية الملكية الفكرية."
      }
    },
    footer: {
      desc: "المؤسسة الاستشارية الرائدة لخدمات ودعم طلبة الدراسات العليا والباحثين في دولة الكويت ودول مجلس التعاون الخليجي، نحو أبحاث علمية رصينة ونزاهة أكاديمية مطلقة.",
      quickLinks: "روابط سريعة",
      legalNotice: "تنويه أكاديمي وأخلاقي",
      legalText: "تلتزم «أورا للأفكار» بالمعايير الأخلاقية والأكاديمية العالمية. خدماتنا مصممة كاستشارات وتوجيه وإرشاد علمي وتدقيق منهجي لدعم الباحث في بناء قدراته وإجازة أطروحته بنفسه، ونرفض رفضاً قاطعاً أي أعمال تنتقص من أمانة العلم أو تخالف لوائح الجامعات.",
      copyright: "جميع الحقوق محفوظة © 2026 أورا للأفكار (Aura Ideas Kuwait) - الصرح الأكاديمي للاستشارات والبحوث.",
      location: "الكويت - الخليج العربي"
    }
  },
  en: {
    nav: {
      brand: "Aura Ideas",
      subBrand: "Academic Consultation & Research Support",
      about: "About Us",
      visionMission: "Vision & Mission",
      values: "Values & Rigor",
      standards: "Citation Standards",
      disciplines: "Disciplines",
      process: "Methodology",
      qualityCheck: "Integrity & Originality",
      universities: "Accredited Universities",
      faq: "FAQ",
      contact: "Contact",
      requestConsultation: "Free Consultation",
      quickCall: "Academic Hotline",
      kuwaitOffice: "Kuwait & GCC",
      whatsapp: "Instant WhatsApp Chat"
    },
    hero: {
      tag: "The Premier Academic Mentoring & Research Advisory Institution in Kuwait & GCC",
      titleStart: "Illuminating Your Path Toward",
      titleHighlight: "Academic Distinction & Excellence",
      subtitle: "At Aura Ideas, we harness the expertise of seasoned doctoral mentors and university professors to provide precision research consultations, methodological rigor, and thesis guidance for postgraduate scholars (Master's & PhD), strictly aligned with Kuwaiti and international university bylaws.",
      ctaPrimary: "Request Specialized Consultation",
      ctaSecondary: "Explore Our Methodology",
      guarantees: [
        "100% Academic Originality & Zero-Plagiarism Guarantee",
        "Certified Authenticity & Similarity Reports With Every Milestone",
        "Continuous Mentoring Through Final Viva Defense",
        "Strict Non-Disclosure & Intellectual Property Protection"
      ]
    },
    stats: [
      {
        number: "12+",
        label: "Years of Experience",
        description: "Empowering postgraduate researchers across the Gulf region",
        icon: "Award"
      },
      {
        number: "2,850+",
        label: "Approved Theses & Papers",
        description: "Master's dissertations, PhD theses, and promotion papers defended with distinction",
        icon: "BookOpenCheck"
      },
      {
        number: "65+",
        label: "Doctoral Consultants",
        description: "Distinguished professors and subject matter specialists",
        icon: "Users"
      },
      {
        number: "0%",
        label: "Unethical Plagiarism",
        description: "Rigorous international citation and originality compliance",
        icon: "ShieldCheck"
      }
    ] as StatItem[],
    aboutStory: {
      badge: "Genesis & Purpose",
      title: "Why Aura Ideas Was Founded",
      p1: "Aura Ideas was born out of a critical need in the Kuwaiti and Gulf academic ecosystem: the absence of a truly ethical, high-caliber scientific partner dedicated to elevating research standards and counteracting commercial, low-grade paper mills.",
      p2: "We believe scientific research is an intellectual legacy requiring exactitude, structured empirical inquiry, and meticulous alignment with the guidelines of prestigious graduate colleges such as Kuwait University, GUST, AUM, Arab Open University, PAAET, as well as renowned UK, US, Egyptian, and Jordanian institutions.",
      p3: "Our philosophy rejects opaque ghostwriting in favor of 'Academic Mentoring and Rigorous Scientific Coaching'. We equip scholars to fully comprehend their methodology, defend their statistical models, and articulate their novel contribution (Research Gap) before examination committees with unshakeable confidence.",
      pillars: [
        {
          title: "Sound Theoretical Framing",
          desc: "Constructing precise research problems and hypotheses via validated scientific methods."
        },
        {
          title: "Uncompromising Integrity",
          desc: "Zero tolerance for plagiarism or crude algorithmic rewrites; authentic, scholar-crafted writing."
        },
        {
          title: "Viva & Defense Preparation",
          desc: "Simulated mock examinations to prepare researchers for committee scrutiny and rebuttals."
        },
        {
          title: "Cutting-Edge Statistical Tooling",
          desc: "Mastery of advanced analytics including SPSS, AMOS, SmartPLS 4, R, and NVivo."
        }
      ]
    },
    visionMission: {
      badge: "Strategic Compass",
      title: "Our Vision, Mission & Core Pillars",
      subtitle: "The non-negotiable principles steering every advisory session and scientific draft at Aura Ideas",
      visionTitle: "Our Vision",
      visionDesc: "To stand as the foremost academic beacon in the Middle East and the most trusted partner for graduate researchers, fostering an authentic culture of inquiry and contributing valuable scholarship to high-impact international indexed journals.",
      missionTitle: "Our Mission",
      missionDesc: "To empower Arab and Gulf researchers to complete theses and scientific papers of the highest methodological caliber by providing bespoke academic consultations, exact statistical modeling, and scholarly language refinement, with unwavering adherence to research ethics and complete privacy.",
      values: [
        {
          id: "integrity",
          title: "Academic Integrity & Authenticity",
          subtitle: "Zero-Plagiarism Standard",
          description: "We guarantee 100% authentic academic content, zero data falsification, and provide verified originality reports with full source matching.",
          points: ["Detailed originality verification", "Strict primary source attribution", "Full adherence to IRB ethical guidelines"],
          icon: "Shield",
          color: "emerald"
        },
        {
          id: "confidentiality",
          title: "Absolute Confidentiality (NDA)",
          subtitle: "Data & IP Security",
          description: "All client identities, topics, and drafts are secured by enforceable Non-Disclosure Agreements. We never share or archive your work externally.",
          points: ["Legally binding NDA", "Encrypted file transfer and storage", "Secure deletion of transient files upon completion"],
          icon: "Lock",
          color: "amber"
        },
        {
          id: "precision",
          title: "Methodological Precision",
          subtitle: "University Guide Alignment",
          description: "Robust scholarly execution strictly tailored to your institution's thesis guidelines, from research gap framing to actionable policy recommendations.",
          points: ["100% university handbook compliance", "Exact citation standards (APA, Harvard)", "Dual-tier peer review auditing"],
          icon: "CheckCircle2",
          color: "blue"
        },
        {
          id: "commitment",
          title: "Punctuality & Free Revisions",
          subtitle: "Dedicated Support Until Defense",
          description: "We commit to punctual milestone deliveries and provide unlimited free revisions based on supervisor feedback until final faculty approval.",
          points: ["Agreed milestone timeline", "Complimentary supervisor revisions", "Around-the-clock advisory support"],
          icon: "Clock",
          color: "indigo"
        }
      ] as ValueItem[]
    },
    standards: {
      badge: "Compliance Guide",
      title: "Supported Academic Citation Standards",
      subtitle: "Mastery of the latest editions of global referencing manuals required by Gulf and international universities",
      citationList: [
        {
          id: "apa7",
          name: "American Psychological Association",
          edition: "APA 7th Edition (Current Standard)",
          primaryFields: "Education, Psychology, Business & Management, Nursing, Social Sciences",
          bookExample: {
            inText: "(Al-Otaibi, 2024, p. 45)",
            reference: "Al-Otaibi, N. (2024). Educational leadership strategies in modern Kuwaiti schools (2nd ed.). Al-Falah Publishing."
          },
          journalExample: {
            inText: "(Al-Kandari & Mubarak, 2023)",
            reference: "Al-Kandari, F., & Mubarak, J. (2023). The impact of digital transformation on public sector efficiency in Kuwait. Educational Journal of Kuwait University, 37(146), 89-122. https://doi.org/10.34120/0080-037-146-003"
          },
          keyRules: [
            "Publisher location omitted in 7th edition; DOI formatted as active URL",
            "Up to 20 authors listed in the reference list before using ellipsis",
            "In-text citation for 3+ authors uses 'et al.' right from the first citation"
          ]
        },
        {
          id: "harvard",
          name: "Harvard Referencing System",
          edition: "Harvard Style (Standard for UK & GUST)",
          primaryFields: "Economics, Accounting, Finance, Human Resource Management, Marketing",
          bookExample: {
            inText: "(Al-Shammari 2023: 112)",
            reference: "Al-Shammari, F. (2023) Advanced Financial Analysis of Listed Firms on Boursa Kuwait. Kuwait: Dar Al-Kutub."
          },
          journalExample: {
            inText: "(Al-Mutairi and Brown 2024)",
            reference: "Al-Mutairi, A. and Brown, R. (2024) 'Corporate governance and firm performance in GCC emerging markets', Journal of Financial Regulation and Compliance, 32(2), pp. 210-234."
          },
          keyRules: [
            "Article titles enclosed in single quotation marks; journal titles in italics",
            "Page ranges preceded by 'pp.' for multiple pages or 'p.' for single page",
            "Year placed after author surname with or without brackets depending on faculty rules"
          ]
        },
        {
          id: "mla9",
          name: "Modern Language Association",
          edition: "MLA 9th Edition",
          primaryFields: "English & Arabic Literature, Linguistics, Cultural Studies, Media, Translation",
          bookExample: {
            inText: "(Al-Hajri 78) [no comma, no 'p.']",
            reference: "Al-Hajri, Abdullah. Aesthetics of Narrative in Contemporary Kuwaiti Fiction. National Council for Culture, Arts and Letters, 2022."
          },
          journalExample: {
            inText: "(Al-Awadhi 104)",
            reference: "Al-Awadhi, Sarah. \"Transformations of Poetic Discourse in the Arabian Gulf.\" Alam Al-Fikr Journal, vol. 51, no. 3, 2023, pp. 95-130."
          },
          keyRules: [
            "No comma between author and page number in parenthetical citations",
            "Core elements system organized through containers for periodicals",
            "List titled 'Works Cited' arranged alphabetically with hanging indents"
          ]
        },
        {
          id: "chicago",
          name: "Chicago Manual of Style / Turabian",
          edition: "Chicago 17th Edition",
          primaryFields: "History, Public Law, Political Science, International Relations, Islamic Studies",
          bookExample: {
            inText: "Footnote: 1. Nasser Al-Dosari, Constitutional Evolution of Kuwait (Kuwait: KFAS, 2021), 142.",
            reference: "Al-Dosari, Nasser. Constitutional Evolution of Kuwait: A Comparative Study. Kuwait: Kuwait Foundation for the Advancement of Sciences, 2021."
          },
          journalExample: {
            inText: "Footnote: 2. Yousef Al-Sabah, \"Priorities of Kuwaiti Diplomacy,\" 55.",
            reference: "Al-Sabah, Yousef. \"Priorities of Humanitarian Diplomacy in Kuwaiti Foreign Policy.\" Journal of Gulf and Arabian Peninsula Studies 49, no. 189 (2023): 45-80."
          },
          keyRules: [
            "Notes and Bibliography system utilizing substantive numbered footnotes",
            "Shortened notes utilized for recurring citations (Author, Short Title, Page)",
            "Final bibliography ordered alphabetically with inverted author names"
          ]
        },
        {
          id: "ieee",
          name: "Institute of Electrical and Electronics Engineers",
          edition: "IEEE Standards & Vancouver (Technical)",
          primaryFields: "Computer Science, Artificial Intelligence, Engineering, Health Informatics",
          bookExample: {
            inText: "As demonstrated in [4], the hybrid model...",
            reference: "[4] K. Al-Ghanim and M. Peterson, Deep Learning Architectures for IoT Security in Smart Cities, 2nd ed. Piscataway, NJ: IEEE Press, 2023."
          },
          journalExample: {
            inText: "Recent telemetry benchmarks [7], [12] indicate...",
            reference: "[7] A. Al-Azemi, \"Predictive Maintenance in Petroleum Refineries Using Hybrid LSTM Networks,\" IEEE Transactions on Industrial Informatics, vol. 19, no. 8, pp. 8812-8821, Aug. 2023."
          },
          keyRules: [
            "Bracketed numeric identifiers [1] assigned in order of appearance",
            "References arranged numerically in the final list, not alphabetically",
            "Standard ISO abbreviations for journal titles"
          ]
        }
      ] as CitationStandard[]
    },
    faculties: {
      badge: "Academic Disciplines",
      title: "Fields of Academic Consultation",
      subtitle: "Multi-disciplinary faculty encompassing over 18 specialized fields of study",
      items: [
        {
          id: "business",
          name: "Business & Management Sciences",
          description: "High-level dissertation consulting for MBA, MSc Finance, and DBA candidates in Strategic Management, Islamic Banking, Fintech, and Supply Chain.",
          icon: "TrendingUp",
          degrees: ["MBA", "MSc Finance", "DBA / PhD"],
          subfields: ["Corporate Governance", "Digital Transformation", "Human Resource Strategy", "Auditing & Tax"]
        },
        {
          id: "law",
          name: "Legal Sciences & Jurisprudence",
          description: "Comparative legal studies, commercial law, criminal litigation, international arbitration, and Kuwaiti / GCC statutory compliance.",
          icon: "Scale",
          degrees: ["LL.M", "PhD in Public & Private Law"],
          subfields: ["Civil & Commercial Law", "Cybercrime Regulations", "Labor & Insurance Acts", "Judicial Precedents"]
        },
        {
          id: "education",
          name: "Educational & Curriculum Sciences",
          description: "Development of empirical research instruments (questionnaires, observation cards, diagnostic tests) with Pearson correlation and Cronbach's Alpha.",
          icon: "GraduationCap",
          degrees: ["M.Ed", "PhD in Curriculum & Instruction"],
          subfields: ["EdTech & E-Learning", "School Leadership", "Special Needs & Gifted Ed", "Instructional Design"]
        },
        {
          id: "tech",
          name: "Computer Science & AI",
          description: "Empirical paper formulation and experimental frameworks in Machine Learning, Natural Language Processing, Cyber Defense, and Cloud Computing.",
          icon: "Cpu",
          degrees: ["MSc Computer Science", "PhD AI & Data Science"],
          subfields: ["Deep Learning Models", "IoT Security Protocols", "Big Data Analytics", "Computer Vision Systems"]
        },
        {
          id: "stats",
          name: "Statistical Analysis & Modeling",
          description: "Specialized biostatistics and quantitative analytics: hypothesis testing, regression models, and Structural Equation Modeling (SEM).",
          icon: "BarChart3",
          degrees: ["SPSS & AMOS", "SmartPLS 4", "R & Python Data"],
          subfields: ["Linear & Logistic Regression", "Exploratory & Confirmatory Factor Analysis", "ANOVA & T-Tests", "Path Analysis"]
        },
        {
          id: "humanities",
          name: "Linguistics & Social Sciences",
          description: "Rigorous scholarship in Sociology, Digital Media & Communications, Applied Linguistics, Translation Studies, and Critical Discourse Analysis.",
          icon: "Languages",
          degrees: ["MA Linguistics", "MA Mass Communications"],
          subfields: ["Critical Discourse Analysis", "Social Media & Identity", "Family Sociology", "Scholarly Translation"]
        }
      ] as FacultyField[]
    },
    qualitySimulator: {
      badge: "Integrity Simulator",
      title: "How We Verify Quality & Authenticity",
      subtitle: "Experience our multi-tier verification process and plagiarism detection simulation live",
      tryLabel: "Select Verification Dimension:",
      tabs: {
        plagiarism: "Plagiarism & Originality Inspection",
        methodology: "Methodological Rigor & Gap Analysis",
        references: "Source Currency & Authenticity",
        aiDetection: "Human Scholarly Authorship Audit"
      }
    },
    roadmap: {
      badge: "Methodological Roadmap",
      title: "From Initial Inquiry to Successful Viva",
      subtitle: "Five transparent, milestone-driven phases ensuring structured execution aligned with faculty bylaws",
      steps: [
        {
          step: 1,
          title: "Topic Framing & Research Gap Identification",
          duration: "Milestone 1",
          description: "Initial consultation to delineate a novel research problem grounded in high-impact 2022-2025 literature, ensuring a distinct academic contribution.",
          deliverables: ["Refined research title", "Problem statement & significance", "Preliminary conceptual map"]
        },
        {
          step: 2,
          title: "Comprehensive Research Proposal",
          duration: "Milestone 2",
          description: "Drafting an airtight dissertation proposal fulfilling all committee prerequisites: research questions, hypotheses, scope, and proposed methodology.",
          deliverables: ["Approved formal proposal", "Exploratory literature review", "Thesis chapter blueprint"]
        },
        {
          step: 3,
          title: "Critical Literature Review & Theoretical Framework",
          duration: "Milestone 3",
          description: "Synthesizing theoretical paradigms and recent empirical studies with analytical critique, avoiding descriptive cataloging while referencing via university style.",
          deliverables: ["Theoretical framework chapter", "Empirical study comparative matrix", "Synthesis of study distinctiveness"]
        },
        {
          step: 4,
          title: "Methodological Design & Statistical Analytics",
          duration: "Milestone 4",
          description: "Sampling design, instrument validation (validity & reliability), empirical data processing via SPSS or SmartPLS, and scientific discussion of outcomes.",
          deliverables: ["Validated data collection instrument", "Statistical tables & narrative interpretation", "Discussion linked to prior literature"]
        },
        {
          step: 5,
          title: "Final Auditing, Plagiarism Verification & Viva Coaching",
          duration: "Milestone 5",
          description: "Proofreading, layout formatting per university guidelines, official originality clearance, and mock defense preparation to master examiners' inquiries.",
          deliverables: ["Print-ready thesis volume", "Certified 0% plagiarism report", "Viva examination preparation dossier"]
        }
      ] as RoadmapStep[]
    },
    universities: {
      badge: "Compliance & Accreditations",
      title: "Universities We Align With",
      subtitle: "In-depth familiarity with graduate school bylaws in Kuwait and international destinations",
      list: [
        { name: "Kuwait University (KU)", category: "National Premier University", location: "Shadadiya / Kaifan, Kuwait", badge: "College of Graduate Studies Bylaws" },
        { name: "Gulf University for Science & Technology (GUST)", category: "Premier Private University", location: "Mishref, Kuwait", badge: "Harvard & APA Formatting Alignment" },
        { name: "American University of the Middle East (AUM)", category: "Business & Engineering Campus", location: "Egaila, Kuwait", badge: "MBA & Graduate Technical Standards" },
        { name: "Public Authority for Applied Education (PAAET)", category: "Applied & Training Colleges", location: "Shuwaikh, Kuwait", badge: "Faculty Promotion & Specialized Research" },
        { name: "Arab Open University (AOU)", category: "UK Open University Partnership", location: "Ardiya, Kuwait", badge: "Education & Computing Master's Guidelines" },
        { name: "UK & US Partner Universities", category: "International Scholarships", location: "United Kingdom & United States", badge: "Dedicated Support for Kuwaiti Sponsored Scholars" }
      ] as UniversityPartner[]
    },
    testimonials: {
      badge: "Scholar Testimonials",
      title: "What Graduate Researchers in Kuwait Say",
      subtitle: "Documented success stories of researchers who graduated with highest honors and publication recommendations",
      list: [
        {
          name: "Dr. Meshari Al-Hajri",
          degree: "PhD in Human Resource Strategy",
          university: "Sponsored Scholar, United Kingdom",
          faculty: "Business School",
          year: "2024",
          quote: "I was stuck with complex structural equation modeling on SmartPLS. The team at Aura Ideas not only assisted with immaculate analytical precision, but the mentor also walked me through each table so I could defend every correlation confidently before my committee.",
          rating: 5
        },
        {
          name: "Noura Al-Azemi",
          degree: "Master of Educational Leadership",
          university: "Kuwait University - Graduate Studies",
          faculty: "College of Education",
          year: "2024",
          quote: "Their strict adherence to Kuwait University's APA 7th handbook and rapid response to my advisor's feedback was stellar. Revisions were completed promptly without any hassle, and the originality report was completely clean.",
          rating: 5
        },
        {
          name: "Eng. Abdulaziz Al-Shammari",
          degree: "Master of Business Administration (MBA)",
          university: "American University of the Middle East (AUM)",
          faculty: "School of Business",
          year: "2023",
          quote: "Total confidentiality and academic professionalism were evident from day one. They supported my proposal framing and critical literature synthesis using peer-reviewed sources from ScienceDirect and Emerald.",
          rating: 5
        }
      ] as Testimonial[]
    },
    faq: {
      badge: "Clarity & Transparency",
      title: "Frequently Asked Questions",
      subtitle: "Transparent answers about our ethical framework and service standards",
      items: [
        {
          category: "Service Scope",
          question: "Does Aura Ideas provide pre-written theses, or consultation and mentoring?",
          answer: "Aura Ideas is an institutional academic consultancy adhering strictly to ethical research mentoring. We do not provide ghostwriting or unethical shortcuts. Instead, we assist researchers in resolving complex methodological obstacles, refining drafts, formatting citations, and analyzing quantitative data, ensuring you master your subject matter and successfully defend it."
        },
        {
          category: "Originality & Plagiarism",
          question: "How do you guarantee that research work is completely plagiarism-free?",
          answer: "We provide an official, itemized certified originality report with every project milestone. Our work guarantees genuine conceptual development, zero unauthorized duplication, and primary source citation in accordance with your university's permissible similarity threshold."
        },
        {
          category: "Supervisor Revisions",
          question: "What happens if my thesis supervisor or committee requests revisions?",
          answer: "We provide an unlimited free revision guarantee for all feedback provided by your university supervisor, within the scope of the agreed research proposal. Our support continues until your thesis receives formal committee approval."
        },
        {
          category: "Confidentiality",
          question: "Are my personal information and research ideas protected?",
          answer: "Yes, confidentiality is the bedrock of Aura Ideas. Every engagement is protected by a binding Non-Disclosure Agreement (NDA). Your identity, manuscripts, and data are stored on encrypted servers and never disclosed or recycled."
        },
        {
          category: "Milestones & Delivery",
          question: "How are project milestones scheduled and delivered?",
          answer: "We work on a staged milestone timeline (Proposal, Chapter 1, Chapter 2, etc.). You inspect and approve each stage before proceeding to the next, with secure, verified payment channels suitable for Kuwait and GCC residents."
        }
      ] as FaqItem[]
    },
    contact: {
      badge: "Direct Contact",
      title: "Embark on Your Research Journey with Confidence",
      subtitle: "Connect with our senior academic advisor today for a free diagnostic evaluation of your research project",
      hotlineTitle: "Direct Kuwait & GCC Academic Hotline",
      whatsappCta: "Message Us Directly on WhatsApp",
      emailTitle: "Official Academic Consultation Email",
      officeTitle: "Kuwait Headquarters & GCC Operations",
      officeDesc: "Kuwait City, State of Kuwait | Serving researchers across Kuwait, Saudi Arabia, Qatar, UAE, Bahrain & Oman",
      form: {
        title: "Request a Confidential Consultation",
        nameLabel: "Full Name",
        namePlaceholder: "Enter your full name",
        phoneLabel: "WhatsApp Number (with country code)",
        phonePlaceholder: "+965 XXXXXXXX",
        universityLabel: "University / Academic Institution",
        universityPlaceholder: "e.g., Kuwait University / GUST / AUM / Other",
        degreeLabel: "Degree Level",
        degrees: ["Master's Degree (MSc / MA / MBA)", "Doctorate (PhD / DBA)", "Bachelor's Capstone", "Faculty Academic Promotion Research", "Indexed Journal Publication (Scopus / ISI)"],
        serviceLabel: "Required Service",
        services: [
          "Full Research Proposal Development",
          "Literature Review & Theoretical Framework",
          "Methodological Design & Research Instruments",
          "Statistical Analysis & Interpretation (SPSS / AMOS)",
          "Scholarly Proofreading & Academic Translation",
          "Certified Plagiarism Inspection & Rectification",
          "Supervisor Revision & Comprehensive Overhaul",
          "Viva Preparation & Defense Simulation"
        ],
        notesLabel: "Research Details & Topic Summary",
        notesPlaceholder: "Provide a brief description of your topic, methodology, or university deadline...",
        submitBtn: "Submit Consultation Request (Immediate Advisor Follow-up)",
        secureNote: "🔒 All inquiries are strictly confidential and protected by our Non-Disclosure Agreement."
      }
    },
    footer: {
      desc: "The leading academic consultancy dedicated to postgraduate researchers and academics across Kuwait and the Arabian Gulf, championing scientific precision and ethical inquiry.",
      quickLinks: "Quick Navigation",
      legalNotice: "Academic & Ethical Disclaimer",
      legalText: "Aura Ideas strictly adheres to international ethical codes of scientific research. Our services are structured as scientific consultation, mentoring, and methodological auditing to build research literacy and assist scholars in independently defending their dissertations. We strictly reject unauthorized academic misrepresentation.",
      copyright: "All Rights Reserved © 2026 Aura Ideas Kuwait - Academic Consultation & Research Support.",
      location: "Kuwait - Arabian Gulf"
    }
  }
};
