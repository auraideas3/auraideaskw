import React, { useState, useEffect } from 'react';
import { Language } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutStory } from './components/AboutStory';
import { VisionMissionValues } from './components/VisionMissionValues';
import { AcademicStandards } from './components/AcademicStandards';
import { QualitySimulator } from './components/QualitySimulator';
import { FacultiesAndFields } from './components/FacultiesAndFields';
import { RoadmapProcess } from './components/RoadmapProcess';
import { KuwaitUniversities } from './components/KuwaitUniversities';
import { Testimonials } from './components/Testimonials';
import { ConsultationSection } from './components/ConsultationSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { ConsultationModal } from './components/ConsultationModal';

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [isConsultModalOpen, setIsConsultModalOpen] = useState<boolean>(false);
  const [prefilledField, setPrefilledField] = useState<string>('');

  useEffect(() => {
    // Synchronize HTML lang and direction
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const handleToggleLang = () => {
    setLang(prev => (prev === 'ar' ? 'en' : 'ar'));
  };

  const handleSelectField = (fieldName: string) => {
    setPrefilledField(fieldName);
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className={`min-h-screen flex flex-col bg-slate-50 text-slate-900 ${lang === 'ar' ? 'font-display' : 'font-latin'}`}>
      {/* Navigation */}
      <Navbar
        lang={lang}
        onToggleLang={handleToggleLang}
        onOpenConsultation={() => setIsConsultModalOpen(true)}
      />

      {/* Main Content Areas */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero 
          lang={lang} 
          onOpenConsultation={() => setIsConsultModalOpen(true)} 
        />

        {/* Story & Philosophy */}
        <AboutStory 
          lang={lang} 
        />

        {/* Vision, Mission & Core Values */}
        <VisionMissionValues 
          lang={lang} 
        />

        {/* Academic Standards & Citation System */}
        <AcademicStandards 
          lang={lang} 
        />

        {/* Interactive Quality & Plagiarism Simulator */}
        <QualitySimulator 
          lang={lang} 
        />

        {/* Academic Disciplines & Faculties */}
        <FacultiesAndFields 
          lang={lang} 
          onSelectField={handleSelectField}
        />

        {/* 5-Step Methodological Roadmap */}
        <RoadmapProcess 
          lang={lang} 
        />

        {/* Kuwait & GCC University Bylaws Compliance */}
        <KuwaitUniversities 
          lang={lang} 
        />

        {/* Testimonials */}
        <Testimonials 
          lang={lang} 
        />

        {/* Consultation & WhatsApp Direct Booking Form */}
        <ConsultationSection 
          lang={lang} 
          prefilledField={prefilledField}
        />

        {/* Frequently Asked Questions */}
        <FaqSection 
          lang={lang} 
        />
      </main>

      {/* Footer */}
      <Footer 
        lang={lang} 
      />

      {/* Quick Consultation Popup Modal */}
      <ConsultationModal
        isOpen={isConsultModalOpen}
        onClose={() => setIsConsultModalOpen(false)}
        lang={lang}
      />
    </div>
  );
}
