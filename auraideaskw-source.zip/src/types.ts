export type Language = 'ar' | 'en';

export interface StatItem {
  number: string;
  label: string;
  description: string;
  icon: string;
}

export interface ValueItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  points: string[];
  icon: string;
  color: string;
}

export interface FacultyField {
  id: string;
  name: string;
  description: string;
  icon: string;
  degrees: string[];
  subfields: string[];
}

export interface CitationStandard {
  id: string;
  name: string;
  edition: string;
  primaryFields: string;
  bookExample: {
    inText: string;
    reference: string;
  };
  journalExample: {
    inText: string;
    reference: string;
  };
  keyRules: string[];
}

export interface RoadmapStep {
  step: number;
  title: string;
  duration: string;
  deliverables: string[];
  description: string;
}

export interface UniversityPartner {
  name: string;
  category: string;
  location: string;
  badge: string;
}

export interface Testimonial {
  name: string;
  degree: string;
  university: string;
  faculty: string;
  year: string;
  quote: string;
  rating: number;
}

export interface FaqItem {
  question: string;
  answer: string;
  category: string;
}
