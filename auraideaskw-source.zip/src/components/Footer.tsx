import React from 'react';
import { 
  GraduationCap, 
  MessageCircle, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  ArrowUp,
  Heart
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface FooterProps {
  lang: Language;
}

export const Footer: React.FC<FooterProps> = ({ lang }) => {
  const t = contentData[lang].footer;
  const isAr = lang === 'ar';

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0e2433] text-slate-400 text-xs sm:text-sm border-t border-[#193f59]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-[#193f59]/80">
          
          {/* Brand Info */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#2e7097] to-[#193f59] border border-[#61ce70]/30 flex items-center justify-center text-[#86efac] shadow-md">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-white tracking-tight font-display">
                  {contentData[lang].nav.brand}
                </span>
                <span className="text-[11px] text-[#86efac] font-medium">
                  {contentData[lang].nav.subBrand}
                </span>
              </div>
            </div>

            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed max-w-sm">
              {t.desc}
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://wa.me/971588740073"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-xl bg-[#193f59] hover:bg-[#61ce70] hover:text-[#0e2433] text-[#86efac] border border-[#2e7097]/40 flex items-center justify-center transition-all cursor-pointer"
                title="WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
              <a
                href="mailto:auraideas1@gmail.com"
                className="w-9 h-9 rounded-xl bg-[#193f59] hover:bg-[#2e7097] hover:text-white text-slate-300 border border-[#2e7097]/40 flex items-center justify-center transition-all cursor-pointer"
                title="Email"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              {t.quickLinks}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#about" className="hover:text-[#86efac] transition-colors">
                  {contentData[lang].nav.about}
                </a>
              </li>
              <li>
                <a href="#vision-mission" className="hover:text-[#86efac] transition-colors">
                  {contentData[lang].nav.visionMission}
                </a>
              </li>
              <li>
                <a href="#standards" className="hover:text-[#86efac] transition-colors">
                  {contentData[lang].nav.standards}
                </a>
              </li>
              <li>
                <a href="#disciplines" className="hover:text-[#86efac] transition-colors">
                  {contentData[lang].nav.disciplines}
                </a>
              </li>
              <li>
                <a href="#quality-check" className="hover:text-[#86efac] transition-colors">
                  {contentData[lang].nav.qualityCheck}
                </a>
              </li>
              <li>
                <a href="#universities" className="hover:text-[#86efac] transition-colors">
                  {contentData[lang].nav.universities}
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-[#86efac] transition-colors">
                  {contentData[lang].nav.faq}
                </a>
              </li>
            </ul>
          </div>

          {/* Ethical Disclaimer */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#86efac] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#61ce70]" />
              <span>{t.legalNotice}</span>
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed bg-[#193f59]/50 p-3.5 rounded-xl border border-[#2e7097]/30">
              {t.legalText}
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              <MapPin className="w-3.5 h-3.5 text-[#61ce70]" />
              <span>{t.location}</span>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>{t.copyright}</p>
          
          <button
            onClick={scrollToTop}
            className="inline-flex items-center gap-1.5 text-slate-400 hover:text-[#86efac] transition-colors cursor-pointer"
          >
            <span>{isAr ? 'العودة إلى أعلى الصفحة' : 'Back to top'}</span>
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Floating WhatsApp Action Button */}
      <aside aria-label={isAr ? 'الدعم الأكاديمي السريع' : 'Quick Academic Support'} className={`fixed bottom-6 ${isAr ? 'left-6' : 'right-6'} z-40`}>
        <a
          href="https://wa.me/971588740073?text=مرحباً،%20أود%20الاستفسار%20عن%20خدمات%20أورا%20للأفكار%20الأكاديمية"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#61ce70] hover:bg-[#4eb85d] text-[#0e2433] font-bold text-xs sm:text-sm shadow-xl hover:shadow-[#61ce70]/30 transition-all hover:scale-105"
        >
          <MessageCircle className="w-5 h-5 text-[#0e2433]" />
          <span className="hidden sm:inline">{isAr ? 'استشر باحث دكتوراه الآن' : 'Chat with Academic Advisor'}</span>
        </a>
      </aside>
    </footer>
  );
};
