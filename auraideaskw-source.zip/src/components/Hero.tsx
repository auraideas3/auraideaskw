import React from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  BookOpenCheck, 
  Award, 
  Users, 
  CheckCircle2, 
  GraduationCap, 
  FileText,
  FileSpreadsheet
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface HeroProps {
  lang: Language;
  onOpenConsultation: () => void;
}

export const Hero: React.FC<HeroProps> = ({ lang, onOpenConsultation }) => {
  const t = contentData[lang].hero;
  const stats = contentData[lang].stats;
  const isAr = lang === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:pt-14 lg:pb-24 bg-gradient-to-b from-[#0e2433] via-[#143247] to-[#193f59] text-white">
      {/* Subtle Background Pattern */}
      <div className="absolute inset-0 dark-pattern opacity-30 pointer-events-none"></div>
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#2e7097]/20 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-[#61ce70]/15 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Hero Narrative */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-start">
            
            {/* Institution Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#61ce70]/15 border border-[#61ce70]/30 text-[#86efac] text-xs sm:text-sm font-semibold backdrop-blur-sm">
              <span className="w-2 h-2 rounded-full bg-[#61ce70] animate-ping"></span>
              <span>{t.tag}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.2] font-display">
              <span>{t.titleStart} </span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#61ce70] via-[#a7f3d0] to-[#61ce70]">
                {t.titleHighlight}
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-200 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
              {t.subtitle}
            </p>

            {/* Guarantees Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 text-sm text-slate-200">
              {t.guarantees.map((guarantee, idx) => (
                <div key={idx} className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-[#61ce70]/20 text-[#86efac] flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <span className="font-medium text-slate-200">{guarantee}</span>
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
              <button
                onClick={onOpenConsultation}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl bg-[#61ce70] hover:bg-[#52b860] text-[#0e2433] font-black text-base shadow-lg shadow-[#61ce70]/25 transition-all duration-200 active:scale-95 cursor-pointer"
              >
                <Sparkles className="w-5 h-5 text-[#0e2433]" />
                <span>{t.ctaPrimary}</span>
                <ArrowIcon className="w-4 h-4" />
              </button>

              <a
                href="#quality-check"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-semibold text-base transition-colors"
              >
                <BookOpenCheck className="w-5 h-5 text-[#86efac]" />
                <span>{isAr ? 'محاكي فحص الاستلال والجودة' : 'Live Plagiarism & Quality Simulator'}</span>
              </a>
            </div>
          </div>

          {/* Hero Visual Card / Interactive Quality Showcase */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl bg-gradient-to-b from-[#16384e]/95 to-[#0f2737]/95 p-6 sm:p-8 border border-[#2e7097]/40 shadow-2xl backdrop-blur-md">
              {/* Header inside card */}
              <div className="flex items-center justify-between pb-5 border-b border-[#2e7097]/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#61ce70]/20 text-[#86efac] flex items-center justify-center">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">
                      {isAr ? 'ميثاق الجودة الأكاديمية' : 'Academic Quality Charter'}
                    </h3>
                    <p className="text-xs text-[#86efac] font-medium">
                      {isAr ? 'معتمد لجامعات الكويت والخليج' : 'Kuwait & GCC Universities Certified'}
                    </p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-md bg-[#61ce70]/20 text-[#86efac] text-xs font-bold border border-[#61ce70]/30">
                  {isAr ? 'أصالة 100%' : '100% Original'}
                </span>
              </div>

              {/* Verified Features in Card */}
              <div className="space-y-4 py-5">
                <div className="p-3.5 rounded-xl bg-[#0e2433]/70 border border-[#2e7097]/30 flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-[#61ce70]/15 text-[#86efac] shrink-0 mt-0.5">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-100">
                      {isAr ? 'فحص استلال علمي رسمي معتمد' : 'Official Originality Verification'}
                    </h4>
                    <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                      {isAr ? 'استخراج تقرير استلال رسمي دقيق بنسبة مطابقة لا تتجاوز النسب المسموح بها في لائحة جامعتك.' : 'Zero illicit duplication with detailed source matching matching your faculty’s exact bylaws.'}
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#0e2433]/70 border border-[#2e7097]/30 flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-[#2e7097]/25 text-[#93c5fd] shrink-0 mt-0.5">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-100">
                      {isAr ? 'التوثيق بأنظمة APA 7 و Harvard' : 'APA 7th & Harvard Referencing'}
                    </h4>
                    <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                      {isAr ? 'ربط المراجع بأحدث أبحاث 2022-2025 من قواعد البيانات العالمية مثل Scopus و ScienceDirect.' : 'Contemporary 2022-2025 citations indexed in Scopus, Web of Science, and Emerald.'}
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#0e2433]/70 border border-[#2e7097]/30 flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-[#61ce70]/15 text-[#86efac] shrink-0 mt-0.5">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-100">
                      {isAr ? 'تحليل إحصائي مقنن (SPSS / AMOS)' : 'Rigorous Statistical Analysis'}
                    </h4>
                    <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                      {isAr ? 'معالجة الفرضيات وتفسير الجداول مع جلسة توضيحية للباحث لفهم مخرجات التحليل.' : 'Hypothesis testing, SEM path modeling, and 1-on-1 walkthrough for total defense mastery.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Bottom Card Footer */}
              <div className="pt-4 border-t border-[#2e7097]/30 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-[#61ce70]"></span>
                  <span>{isAr ? 'اتفاقية سرية قانونية (NDA)' : 'Protected by Binding NDA'}</span>
                </div>
                <a 
                  href="#standards" 
                  className="text-[#86efac] hover:text-white font-semibold inline-flex items-center gap-1 transition-colors"
                >
                  <span>{isAr ? 'استعراض الأنظمة' : 'View Standards'}</span>
                  <ArrowIcon className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Highlighted Quantitative Metrics Bar */}
        <div className="mt-16 pt-10 border-t border-[#2e7097]/30 grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, idx) => {
            const IconComponent = 
              stat.icon === 'Award' ? Award :
              stat.icon === 'BookOpenCheck' ? BookOpenCheck :
              stat.icon === 'Users' ? Users : ShieldCheck;

            return (
              <div 
                key={idx} 
                className="p-5 rounded-2xl bg-[#0e2433]/60 border border-[#2e7097]/30 hover:border-[#61ce70]/50 transition-all duration-300 group"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-9 h-9 rounded-lg bg-[#2e7097]/25 text-[#86efac] flex items-center justify-center group-hover:bg-[#61ce70]/20 transition-colors">
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <span className="text-2xl sm:text-3xl font-black text-white font-display">
                    {stat.number}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-slate-200 mb-1">
                  {stat.label}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {stat.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
