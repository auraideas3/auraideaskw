import React, { useState } from 'react';
import { 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Search,
  Sparkles
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface FaqSectionProps {
  lang: Language;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ lang }) => {
  const t = contentData[lang].faq;
  const isAr = lang === 'ar';
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredFaqs = t.items.filter(item => 
    item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-12 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eaf7ed] border border-[#61ce70]/30 text-[#193f59] text-xs font-bold tracking-wide">
            <HelpCircle className="w-3.5 h-3.5 text-[#2e7097]" />
            <span>{t.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#193f59] font-display">
            {t.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.subtitle}
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#2e7097] to-[#61ce70] mx-auto rounded-full mt-4"></div>
        </div>

        {/* Search Bar */}
        <div className="relative mb-8">
          <Search className={`w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 ${isAr ? 'right-4' : 'left-4'}`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'ابحث عن إجابة لسؤالك (مثال: استلال، تعديلات، المشرف، دفع)...' : 'Search FAQ (e.g. plagiarism, supervisor, revisions, payment)...'}
            className={`w-full py-3 rounded-xl bg-white border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097] shadow-xs ${
              isAr ? 'pr-11 pl-4' : 'pl-11 pr-4'
            }`}
          />
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-3">
          {filteredFaqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen 
                    ? 'bg-white border-[#61ce70] shadow-md ring-1 ring-[#61ce70]/30' 
                    : 'bg-white border-slate-200 hover:border-[#2e7097]/40'
                }`}
              >
                <button
                  onClick={() => toggleFaq(idx)}
                  className="w-full p-5 text-start flex items-center justify-between gap-4 cursor-pointer"
                >
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#2e7097] block">
                      {faq.category}
                    </span>
                    <h3 className="text-sm sm:text-base font-bold text-[#193f59] font-display">
                      {faq.question}
                    </h3>
                  </div>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-transform ${
                    isOpen ? 'bg-[#eaf7ed] text-[#15803d]' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}

          {filteredFaqs.length === 0 && (
            <div className="text-center py-8 text-slate-500 text-sm">
              {isAr ? 'لم يتم العثور على نتائج. يمكنك التواصل معنا مباشرة وسيجيبك المستشار فوراً.' : 'No matching questions found. Please contact us directly.'}
            </div>
          )}
        </div>

      </div>
    </section>
  );
};
