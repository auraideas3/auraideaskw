import React, { useState, useEffect, useRef } from 'react';
import { Globe, MessageCircle } from 'lucide-react';
import { Language } from '../types';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  onOpenConsultation: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ lang, onToggleLang, onOpenConsultation }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);
  const servicesRef = useRef<HTMLDetailsElement>(null);
  const isAr = lang === 'ar';

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (servicesRef.current && !servicesRef.current.contains(e.target as Node)) {
        setServicesOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const closeMenus = () => {
    setMobileOpen(false);
    setServicesOpen(false);
  };

  return (
    <header className="aura-header sticky top-0" id="main-header">
      {/* 1. Animated Ticker Bar */}
      <div className="aura-header-motion" aria-label={isAr ? "رسالة أورا المتحركة" : "Aura ticker announcement"}>
        <span>
          {isAr 
            ? 'أورا للأفكار · جودة أكاديمية · وضوح في كل خطوة · استشارة مجانية عبر واتساب' 
            : 'Aura Ideas · Academic Excellence · Clarity in Every Step · Free WhatsApp Consultation'}
        </span>
      </div>

      {/* 2. Floating Vector Book SVG */}
      <span className="aura-floating-book" aria-hidden="true">
        <svg viewBox="0 0 64 64" fill="none" aria-hidden="true">
          <path d="M10 16c10-5 18-4 25 2v35c-7-6-15-7-25-2V16Z" fill="#61ce70" fillOpacity=".3" stroke="currentColor" strokeWidth="2.5" />
          <path d="M54 16c-10-5-18-4-25 2v35c7-6 15-7 25-2V16Z" fill="#2e7097" fillOpacity=".18" stroke="currentColor" strokeWidth="2.5" />
          <path d="M16 25c6-2 11-1 16 2M16 32c6-2 11-1 16 2M48 25c-6-2-11-1-16 2M48 32c-6-2-11-1-16 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity=".8" />
        </svg>
      </span>

      {/* 3. Floating Vector Pen SVG */}
      <span className="aura-floating-pen" aria-hidden="true">
        <svg viewBox="0 0 64 64" fill="none" aria-hidden="true">
          <path d="m17 48 4-13L45 11l8 8-24 24-12 5Z" fill="#2e7097" fillOpacity=".22" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round" />
          <path d="m38 18 8 8M21 35l8 8" stroke="currentColor" strokeWidth="2.5" />
          <path d="m17 48 3-8 5 5-8 3Z" fill="#61ce70" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
          <path d="m45 11 4-3 7 7-3 4-8-8Z" fill="#61ce70" fillOpacity=".7" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
        </svg>
      </span>

      {/* 4. Main Inner Header Bar */}
      <div className="aura-header-inner">
        {/* Mobile Navigation Trigger & Menu */}
        <details className="aura-mobile" open={mobileOpen}>
          <summary 
            aria-label={isAr ? "فتح القائمة" : "Open Menu"}
            onClick={(e) => {
              e.preventDefault();
              setMobileOpen(!mobileOpen);
            }}
          />
          {mobileOpen && (
            <nav className="aura-mobile-menu" aria-label={isAr ? "قائمة الهاتف" : "Mobile Menu"}>
              <a href="#hero" onClick={closeMenus}>
                {isAr ? 'الرئيسية' : 'Home'}
              </a>
              <a href="#about" onClick={closeMenus}>
                {isAr ? 'من نحن' : 'About Us'}
              </a>
              <a href="#standards" onClick={closeMenus}>
                {isAr ? 'الضمانات' : 'Guarantees'}
              </a>

              {/* Mobile Services Accordion */}
              <details open={mobileServicesOpen}>
                <summary 
                  onClick={(e) => {
                    e.preventDefault();
                    setMobileServicesOpen(!mobileServicesOpen);
                  }}
                >
                  {isAr ? 'خدماتنا' : 'Services'}
                </summary>
                <div>
                  <a href="#disciplines" onClick={closeMenus}>
                    {isAr ? 'كل الخدمات' : 'All Services'}
                  </a>
                  <a href="#disciplines" onClick={closeMenus}>
                    {isAr ? 'أبحاث الماجستير' : "Master's Theses"}
                  </a>
                  <a href="#disciplines" onClick={closeMenus}>
                    {isAr ? 'أطروحة الدكتوراه' : 'PhD Dissertations'}
                  </a>
                  <a href="#quality-check" onClick={closeMenus}>
                    {isAr ? 'تنسيق وتدقيق الأبحاث' : 'Formatting & Proofreading'}
                  </a>
                  <a href="#disciplines" onClick={closeMenus}>
                    {isAr ? 'كتابة الأبحاث الجامعية' : 'Academic Papers'}
                  </a>
                  <a href="#disciplines" onClick={closeMenus}>
                    {isAr ? 'مشروع التخرج' : 'Graduation Projects'}
                  </a>
                  <a href="#disciplines" onClick={closeMenus}>
                    {isAr ? 'التحليل الإحصائي' : 'Statistical Analysis'}
                  </a>
                </div>
              </details>

              <a href="#quality-check" onClick={closeMenus}>
                {isAr ? 'تشكيل النصوص' : 'Text Vocalization'}
              </a>
              <a href="#quality-check" onClick={closeMenus}>
                {isAr ? 'حساب العينة' : 'Sample Size Calculator'}
              </a>
              <a href="#universities" onClick={closeMenus}>
                {isAr ? 'كتبنا' : 'Publications'}
              </a>
              <a href="#faq" onClick={closeMenus}>
                {isAr ? 'المدونة' : 'Blog'}
              </a>
              <a href="#testimonials" onClick={closeMenus}>
                {isAr ? 'آراء العملاء' : 'Testimonials'}
              </a>
              <a href="#contact" onClick={closeMenus}>
                {isAr ? 'تواصل معنا' : 'Contact Us'}
              </a>

              {/* Language Switch in Mobile Menu */}
              <button 
                type="button" 
                onClick={() => {
                  onToggleLang();
                  closeMenus();
                }}
                className="w-full text-right py-3 px-4 rounded-lg bg-slate-100 text-slate-800 font-bold text-sm flex items-center justify-between mt-2"
              >
                <span>{isAr ? 'تغيير اللغة' : 'Change Language'}</span>
                <span className="text-emerald-700 font-semibold">{isAr ? 'English' : 'العربية'}</span>
              </button>

              <a 
                className="aura-mobile-request" 
                href="https://wa.me/971588740073" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                {isAr ? 'اطلب خدمتك الآن' : 'Request Service Now'}
              </a>
            </nav>
          )}
        </details>

        {/* Brand Official Logo */}
        <a className="aura-logo" href="#hero" aria-label={isAr ? "العودة إلى الرئيسية" : "Back to Home"}>
          <img 
            src="/aura-logo.png" 
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://aura-ideas.com/wp-content/uploads/2025/12/cropped-aura.png';
            }} 
            alt="شعار أورا للأفكار - Aura Ideas" 
          />
        </a>

        {/* Desktop Navigation */}
        <nav className="aura-nav" aria-label={isAr ? "القائمة الرئيسية" : "Main Navigation"}>
          <a href="#hero">
            {isAr ? 'الرئيسية' : 'Home'}
          </a>
          <a href="#about">
            {isAr ? 'من نحن' : 'About Us'}
          </a>
          <a href="#standards">
            {isAr ? 'الضمانات' : 'Guarantees'}
          </a>

          {/* Services Dropdown */}
          <details className="aura-services" ref={servicesRef} open={servicesOpen}>
            <summary 
              onClick={(e) => {
                e.preventDefault();
                setServicesOpen(!servicesOpen);
              }}
            >
              {isAr ? 'خدماتنا' : 'Services'}
            </summary>
            {servicesOpen && (
              <div className="aura-services-menu">
                <a href="#disciplines" onClick={() => setServicesOpen(false)}>
                  {isAr ? 'كل الخدمات' : 'All Services'}
                </a>
                <a href="#disciplines" onClick={() => setServicesOpen(false)}>
                  {isAr ? 'أبحاث الماجستير' : "Master's Theses"}
                </a>
                <a href="#disciplines" onClick={() => setServicesOpen(false)}>
                  {isAr ? 'أطروحة الدكتوراه' : 'PhD Dissertations'}
                </a>
                <a href="#quality-check" onClick={() => setServicesOpen(false)}>
                  {isAr ? 'تنسيق وتدقيق الأبحاث' : 'Formatting & Proofreading'}
                </a>
                <a href="#disciplines" onClick={() => setServicesOpen(false)}>
                  {isAr ? 'كتابة الأبحاث الجامعية' : 'Academic Papers'}
                </a>
                <a href="#disciplines" onClick={() => setServicesOpen(false)}>
                  {isAr ? 'مشروع التخرج' : 'Graduation Projects'}
                </a>
                <a href="#disciplines" onClick={() => setServicesOpen(false)}>
                  {isAr ? 'التحليل الإحصائي' : 'Statistical Analysis'}
                </a>
              </div>
            )}
          </details>

          <a href="#quality-check">
            {isAr ? 'تشكيل النصوص' : 'Text Vocalization'}
          </a>
          <a href="#quality-check">
            {isAr ? 'حساب العينة' : 'Sample Calculator'}
          </a>
          <a href="#universities">
            {isAr ? 'كتبنا' : 'Publications'}
          </a>
          <a href="#faq">
            {isAr ? 'المدونة' : 'Blog'}
          </a>
          <a href="#testimonials">
            {isAr ? 'آراء العملاء' : 'Testimonials'}
          </a>
          <a href="#contact">
            {isAr ? 'تواصل معنا' : 'Contact Us'}
          </a>
        </nav>

        {/* Right Actions: Language Switch & CTA */}
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleLang}
            className="aura-lang-btn"
            title={isAr ? 'Switch to English' : 'التحويل للعربية'}
            aria-label="تبديل اللغة"
          >
            <Globe className="w-4 h-4 text-[#2e7097]" />
            <span>{isAr ? 'EN' : 'عربي'}</span>
          </button>

          <a 
            className="aura-request cursor-pointer" 
            href="https://wa.me/971588740073" 
            target="_blank" 
            rel="noopener noreferrer"
            onClick={(e) => {
              // Open WhatsApp with prefilled message
            }}
          >
            {isAr ? 'اطلب خدمتك الآن' : 'Request Service'}
          </a>
        </div>
      </div>
    </header>
  );
};
