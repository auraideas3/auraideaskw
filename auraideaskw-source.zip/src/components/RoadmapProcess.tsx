import React, { useState } from 'react';
import { 
  GitCommit, 
  CheckCircle2, 
  Clock, 
  FileCheck, 
  Sparkles, 
  Layers,
  ArrowRight,
  ArrowLeft
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface RoadmapProcessProps {
  lang: Language;
}

export const RoadmapProcess: React.FC<RoadmapProcessProps> = ({ lang }) => {
  const t = contentData[lang].roadmap;
  const isAr = lang === 'ar';
  const [activeStep, setActiveStep] = useState<number>(1);

  const selectedStep = t.steps.find(s => s.step === activeStep) || t.steps[0];

  return (
    <section id="process" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eaf7ed] border border-[#61ce70]/30 text-[#193f59] text-xs font-bold tracking-wide">
            <GitCommit className="w-3.5 h-3.5 text-[#2e7097]" />
            <span>{t.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#193f59] font-display">
            {t.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.subtitle}
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#2e7097] to-[#61ce70] mx-auto rounded-full mt-4"></div>
        </div>

        {/* Steps Navigation Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 mb-10">
          {t.steps.map((step) => {
            const isCurrent = step.step === activeStep;
            return (
              <button
                key={step.step}
                onClick={() => setActiveStep(step.step)}
                className={`p-4 rounded-xl text-start transition-all duration-200 border flex flex-col justify-between cursor-pointer ${
                  isCurrent
                    ? 'bg-[#193f59] text-white border-[#193f59] shadow-lg scale-[1.02]'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-[#2e7097]/40 hover:bg-[#f0f7f4]'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
                    isCurrent ? 'bg-[#61ce70] text-[#0e2433]' : 'bg-slate-100 text-slate-700'
                  }`}>
                    {step.step}
                  </span>
                  <span className={`text-[10px] font-semibold uppercase tracking-wider ${
                    isCurrent ? 'text-[#86efac]' : 'text-slate-400'
                  }`}>
                    {step.duration}
                  </span>
                </div>
                <h4 className="font-bold text-xs sm:text-sm line-clamp-2 font-display">
                  {step.title}
                </h4>
              </button>
            );
          })}
        </div>

        {/* Selected Step Deep Dive Card */}
        <div className="bg-white rounded-2xl p-6 sm:p-10 border border-slate-200 shadow-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center gap-3">
                <span className="w-9 h-9 rounded-xl bg-[#61ce70] text-[#0e2433] font-black flex items-center justify-center text-lg shadow-xs">
                  {selectedStep.step}
                </span>
                <div>
                  <span className="text-xs font-bold text-[#2e7097] block">{selectedStep.duration}</span>
                  <h3 className="text-xl sm:text-2xl font-bold text-[#193f59] font-display">
                    {selectedStep.title}
                  </h3>
                </div>
              </div>

              <p className="text-sm sm:text-base text-slate-700 leading-relaxed pt-2">
                {selectedStep.description}
              </p>

              <div className="pt-4 border-t border-slate-100">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  {isAr ? 'المخرجات الأكاديمية المسلمة للباحث في هذه المرحلة:' : 'Key Academic Deliverables in This Phase:'}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {selectedStep.deliverables.map((item, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-[#f0f7f4] border border-[#61ce70]/20 flex items-center gap-2 text-xs font-semibold text-slate-800">
                      <CheckCircle2 className="w-4 h-4 text-[#61ce70] shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quality Checkpoint Box */}
            <div className="lg:col-span-5 bg-[#0e2433] border border-[#2e7097]/40 text-white rounded-xl p-6 space-y-4 shadow-xl">
              <div className="flex items-center gap-2 text-[#86efac] font-bold text-sm">
                <Sparkles className="w-4 h-4 text-[#61ce70]" />
                <span>{isAr ? 'نقطة التحقق والضمان في هذه المرحلة' : 'Quality Verification Gate'}</span>
              </div>
              
              <p className="text-xs text-slate-300 leading-relaxed">
                {selectedStep.step === 1 && (isAr ? 'يتم فحص الفكرة ضد بنوك الرسائل الجامعية الخليجية لتفادي التكرار وضمان حداثة العنوان.' : 'The topic is screened against GCC graduate databases to avoid duplication and certify thematic novelty.')}
                {selectedStep.step === 2 && (isAr ? 'مراجعة الخطة وفق معايير لجنة السيمنار بالجامعة وتجهيز شرائح العرض التقديمي (PowerPoint).' : 'Proposal review compliant with university seminar board rubrics, with presentation slides preparation.')}
                {selectedStep.step === 3 && (isAr ? 'فحص استلال علمي فوري وتأصيل المراجع بروابط DOI لضمان خلو الفصل من الحشو والنقل الحرفي.' : 'Immediate originality screening with verified active DOIs to eliminate descriptive filler and direct duplication.')}
                {selectedStep.step === 4 && (isAr ? 'جلسة فيديو أو لقاء صوتي مع الباحث لشرح مخرجات الجداول الإحصائية وطريقة قراءة القيم الدلالية.' : 'Dedicated virtual walkthrough explaining statistical p-values and regression outputs to the researcher.')}
                {selectedStep.step === 5 && (isAr ? 'محاكاة مناقشة افتراضية (Mock Defense) مع توفير كتيّب بأبرز الأسئلة المتوقعة من لجنة التحكيم.' : 'Live simulated defense session with expected questioning matrices to ensure fluent candidate rebuttals.')}
              </p>

              <div className="pt-2 border-t border-[#193f59] flex items-center justify-between text-xs text-slate-400">
                <span>{isAr ? 'تسليم مرحلي معتمد' : 'Milestone Sign-off'}</span>
                <span className="text-[#86efac] font-bold">{isAr ? 'تعديل مجاني وفق المشرف' : 'Free Supervisor Revisions'}</span>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
