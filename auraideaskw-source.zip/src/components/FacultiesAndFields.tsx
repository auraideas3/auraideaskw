import React, { useState } from 'react';
import { 
  TrendingUp, 
  Scale, 
  GraduationCap, 
  Cpu, 
  BarChart3, 
  Languages, 
  Layers, 
  Sparkles,
  CheckCircle,
  ArrowRight,
  ArrowLeft
} from 'lucide-react';
import { Language, FacultyField } from '../types';
import { contentData } from '../data/content';

interface FacultiesAndFieldsProps {
  lang: Language;
  onSelectField?: (fieldName: string) => void;
}

export const FacultiesAndFields: React.FC<FacultiesAndFieldsProps> = ({ lang, onSelectField }) => {
  const t = contentData[lang].faculties;
  const isAr = lang === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const [activeFacultyId, setActiveFacultyId] = useState<string>(t.items[0].id);

  const facultyIcons: Record<string, React.ReactNode> = {
    business: <TrendingUp className="w-5 h-5" />,
    law: <Scale className="w-5 h-5" />,
    education: <GraduationCap className="w-5 h-5" />,
    tech: <Cpu className="w-5 h-5" />,
    stats: <BarChart3 className="w-5 h-5" />,
    humanities: <Languages className="w-5 h-5" />,
  };

  const selectedFaculty = t.items.find(f => f.id === activeFacultyId) || t.items[0];

  return (
    <section id="disciplines" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eaf7ed] border border-[#61ce70]/30 text-[#193f59] text-xs font-bold tracking-wide">
            <Layers className="w-3.5 h-3.5 text-[#2e7097]" />
            <span>{t.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#193f59] font-display">
            {t.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.subtitle}
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#2e7097] to-[#61ce70] mx-auto rounded-full mt-4"></div>
        </div>

        {/* Faculties Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {t.items.map((faculty) => {
            const isSelected = faculty.id === activeFacultyId;
            return (
              <div
                key={faculty.id}
                onClick={() => setActiveFacultyId(faculty.id)}
                className={`p-6 rounded-2xl border transition-all duration-300 cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#f0f7f4] border-[#61ce70] shadow-md ring-1 ring-[#61ce70]/50'
                    : 'bg-slate-50/60 border-slate-200 hover:border-[#2e7097]/40 hover:bg-[#f0f7f4]/40'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                      isSelected ? 'bg-[#193f59] text-[#86efac] shadow-xs' : 'bg-white text-[#2e7097] border border-slate-200'
                    }`}>
                      {facultyIcons[faculty.id]}
                    </div>
                    <div className="flex flex-wrap gap-1 justify-end">
                      {faculty.degrees.slice(0, 2).map((deg, i) => (
                        <span key={i} className="px-2 py-0.5 rounded text-[10px] font-bold bg-white text-slate-700 border border-slate-200">
                          {deg}
                        </span>
                      ))}
                    </div>
                  </div>

                  <h3 className="text-lg font-bold text-[#193f59] mb-2 font-display">
                    {faculty.name}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    {faculty.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-200/80">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    {isAr ? 'أبرز المحاور التخصصية:' : 'Core Research Themes:'}
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {faculty.subfields.map((sf, idx) => (
                      <span key={idx} className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 text-slate-700">
                        {sf}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Faculty Action Callout */}
        <div className="bg-[#0e2433] text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-[#2e7097]/30 shadow-xl">
          <div className="space-y-2 text-center md:text-start">
            <span className="text-xs font-bold text-[#86efac] uppercase tracking-wider">
              {isAr ? 'هل تبحث عن استشارة في هذا المجال التخصصي؟' : 'Looking for Advisory Support in This Field?'}
            </span>
            <h4 className="text-xl font-bold font-display">
              {selectedFaculty.name} — {isAr ? 'مستشارون أكاديميون متخصصون بدرجة أستاذ مشارك ودكتوراه' : 'Supervised by Associate Professors & PhD Mentors'}
            </h4>
            <p className="text-xs text-slate-300 max-w-2xl">
              {isAr ? 'احصل على تحليل أولي لفكرة بحثك وتحديد الفجوة البحثية المناسبة للوائح جامعتك خلال 24 ساعة.' : 'Receive an initial diagnostic appraisal of your research topic and gap formulation within 24 hours.'}
            </p>
          </div>

          <a
            href="#contact"
            onClick={() => onSelectField && onSelectField(selectedFaculty.name)}
            className="shrink-0 inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#61ce70] hover:bg-[#4eb85d] text-[#0e2433] font-bold text-sm shadow-md transition-colors cursor-pointer"
          >
            <span>{isAr ? 'طلب استشارة في هذا التخصص' : 'Consult on This Field'}</span>
            <ArrowIcon className="w-4 h-4" />
          </a>
        </div>

      </div>
    </section>
  );
};
