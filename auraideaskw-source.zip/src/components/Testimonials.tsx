import React from 'react';
import { 
  Quote, 
  Star, 
  GraduationCap, 
  Award,
  CheckCircle2
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface TestimonialsProps {
  lang: Language;
}

export const Testimonials: React.FC<TestimonialsProps> = ({ lang }) => {
  const t = contentData[lang].testimonials;
  const isAr = lang === 'ar';

  return (
    <section className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eaf7ed] border border-[#61ce70]/30 text-[#193f59] text-xs font-bold tracking-wide">
            <Award className="w-3.5 h-3.5 text-[#2e7097]" />
            <span>{t.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#193f59] font-display">
            {t.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.subtitle}
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#2e7097] to-[#61ce70] mx-auto rounded-full mt-4"></div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {t.list.map((item, idx) => (
            <div 
              key={idx}
              className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs hover:shadow-md hover:border-[#61ce70]/50 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Top Quote Icon & Stars */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1 text-[#61ce70]">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#61ce70]" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-[#2e7097]/20" />
                </div>

                {/* Quote Body */}
                <p className="text-slate-700 text-sm leading-relaxed mb-6 italic">
                  "{item.quote}"
                </p>
              </div>

              {/* Author Details */}
              <div className="pt-4 border-t border-slate-100 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#eaf7ed] text-[#193f59] font-bold flex items-center justify-center text-sm border border-[#61ce70]/30">
                  <GraduationCap className="w-5 h-5 text-[#2e7097]" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#193f59] font-display">
                    {item.name}
                  </h4>
                  <p className="text-xs text-[#2e7097] font-semibold">
                    {item.degree}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    {item.university}
                  </p>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
