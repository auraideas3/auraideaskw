import React, { useState } from 'react';
import { 
  X, 
  Send, 
  MessageCircle, 
  CheckCircle, 
  Lock, 
  GraduationCap, 
  Sparkles
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({ isOpen, onClose, lang }) => {
  if (!isOpen) return null;

  const t = contentData[lang].contact;
  const isAr = lang === 'ar';

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [degree, setDegree] = useState(t.form.degrees[0]);
  const [service, setService] = useState(t.form.services[0]);
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const buildWhatsAppLink = () => {
    const message = isAr
      ? `طلب استشارة عاجلة من أورا للأفكار:\n- الاسم: ${name || 'غير محدد'}\n- المرحلة: ${degree}\n- الخدمة: ${service}\n- ملاحظات: ${notes || 'موضوع جديد'}`
      : `Urgent Consultation Request from Aura Ideas:\n- Name: ${name || 'Unspecified'}\n- Degree: ${degree}\n- Service: ${service}\n- Notes: ${notes || 'New Topic'}`;
    
    return `https://wa.me/971588740073?text=${encodeURIComponent(message)}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div 
        className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-[#f0f7f4]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#193f59] text-[#86efac] flex items-center justify-center font-bold shadow-xs">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#193f59] font-display">
                {t.form.title}
              </h3>
              <span className="text-xs text-[#2e7097] font-medium">
                {isAr ? 'تقييم منهجي مجاني وسري' : 'Free Confidential Methodology Audit'}
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-12 h-12 rounded-full bg-[#eaf7ed] text-[#15803d] flex items-center justify-center mx-auto">
                <CheckCircle className="w-7 h-7" />
              </div>
              <h4 className="text-base font-bold text-[#193f59] font-display">
                {isAr ? 'تم تسجيل طلبك بنجاح!' : 'Your Request Has Been Submitted!'}
              </h4>
              <p className="text-xs text-slate-600">
                {isAr ? 'سيتواصل معك المستشار الأكاديمي المختص في غضون دقائق.' : 'Our subject consultant will connect with you via WhatsApp shortly.'}
              </p>
              <div className="pt-2 flex flex-col gap-2">
                <a
                  href={buildWhatsAppLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 rounded-xl bg-[#61ce70] hover:bg-[#4eb85d] text-[#0e2433] font-bold text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{isAr ? 'متابعة المحادثة على واتساب' : 'Continue on WhatsApp'}</span>
                </a>
                <button
                  onClick={onClose}
                  className="w-full py-2 rounded-xl text-xs text-slate-500 hover:bg-slate-100 cursor-pointer"
                >
                  {isAr ? 'إغلاق' : 'Close'}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {t.form.nameLabel} *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t.form.namePlaceholder}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {t.form.phoneLabel} *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder={t.form.phonePlaceholder}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {t.form.degreeLabel}
                  </label>
                  <select
                    value={degree}
                    onChange={(e) => setDegree(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                  >
                    {t.form.degrees.map((deg, idx) => (
                      <option key={idx} value={deg}>{deg}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {t.form.serviceLabel}
                  </label>
                  <select
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                  >
                    {t.form.services.map((srv, idx) => (
                      <option key={idx} value={srv}>{srv}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {t.form.notesLabel}
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={t.form.notesPlaceholder}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                ></textarea>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#193f59] to-[#2e7097] hover:from-[#0e2433] hover:to-[#193f59] text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <Send className="w-3.5 h-3.5 text-[#86efac]" />
                  <span>{isAr ? 'إرسال طلب الاستشارة الفورية' : 'Submit Consultation Request'}</span>
                </button>
              </div>

              <div className="flex items-center justify-center gap-1.5 text-slate-400 text-[10px] pt-1">
                <Lock className="w-3 h-3 text-[#2e7097]" />
                <span>{t.form.secureNote}</span>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
