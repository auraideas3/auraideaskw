import React, { useState } from 'react';
import { 
  BookMarked, 
  Copy, 
  Check, 
  BookOpen, 
  FileText, 
  Info, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { Language, CitationStandard } from '../types';
import { contentData } from '../data/content';

interface AcademicStandardsProps {
  lang: Language;
}

export const AcademicStandards: React.FC<AcademicStandardsProps> = ({ lang }) => {
  const t = contentData[lang].standards;
  const isAr = lang === 'ar';
  const [activeStandardId, setActiveStandardId] = useState<string>(t.citationList[0].id);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const selectedStandard: CitationStandard = t.citationList.find(s => s.id === activeStandardId) || t.citationList[0];

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <section id="standards" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eaf7ed] border border-[#61ce70]/30 text-[#193f59] text-xs font-bold tracking-wide">
            <BookMarked className="w-3.5 h-3.5 text-[#2e7097]" />
            <span>{t.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#193f59] font-display">
            {t.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.subtitle}
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#2e7097] to-[#61ce70] mx-auto rounded-full mt-4"></div>
        </div>

        {/* Standard System Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {t.citationList.map((standard) => {
            const isSelected = standard.id === activeStandardId;
            return (
              <button
                key={standard.id}
                onClick={() => setActiveStandardId(standard.id)}
                className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all duration-200 cursor-pointer flex items-center gap-2 ${
                  isSelected
                    ? 'bg-[#193f59] text-white shadow-md shadow-[#193f59]/20'
                    : 'bg-slate-100 text-slate-700 hover:bg-[#f0f7f4] hover:text-[#193f59]'
                }`}
              >
                <span>{standard.edition.split('(')[0]}</span>
                {isSelected && <Sparkles className="w-3.5 h-3.5 text-[#86efac]" />}
              </button>
            );
          })}
        </div>

        {/* Active Standard Showcase */}
        <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6 sm:p-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-[#eaf7ed] text-[#193f59] border border-[#61ce70]/30">
                  {selectedStandard.id.toUpperCase()}
                </span>
                <h3 className="text-xl font-bold text-[#193f59] font-display">
                  {selectedStandard.name}
                </h3>
              </div>
              <p className="text-xs text-slate-500 font-latin">
                {selectedStandard.edition}
              </p>
            </div>
            
            <div className="bg-white px-3.5 py-2 rounded-xl border border-slate-200 text-xs text-slate-600 max-w-md">
              <span className="font-bold text-[#193f59]">{isAr ? 'المجالات الشائعة: ' : 'Primary Fields: '}</span>
              <span>{selectedStandard.primaryFields}</span>
            </div>
          </div>

          {/* Interactive Examples Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 my-6">
            
            {/* Book Citation Example */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 space-y-4 shadow-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
                  <BookOpen className="w-4 h-4 text-[#2e7097]" />
                  <span>{isAr ? 'نموذج توثيق كتاب (Book Citation)' : 'Book Citation Example'}</span>
                </div>
                <button
                  onClick={() => handleCopy(selectedStandard.bookExample.reference, 'book')}
                  className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-[#2e7097] transition-colors px-2 py-1 rounded bg-slate-50 hover:bg-[#f0f7f4] cursor-pointer"
                  title="نسخ صيغة المرجع"
                >
                  {copiedKey === 'book' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-600 font-semibold">{isAr ? 'تم النسخ!' : 'Copied!'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>{isAr ? 'نسخ المرجع' : 'Copy'}</span>
                    </>
                  )}
                </button>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-slate-400 font-semibold block mb-0.5">
                    {isAr ? 'التوثيق في المتن (In-Text Citation):' : 'In-Text Citation:'}
                  </span>
                  <div className="p-2.5 rounded-lg bg-slate-50 font-mono text-slate-800 text-[11px] border border-slate-100">
                    {selectedStandard.bookExample.inText}
                  </div>
                </div>

                <div>
                  <span className="text-slate-400 font-semibold block mb-0.5">
                    {isAr ? 'قائمة المراجع النهائية (Reference List):' : 'Reference List Entry:'}
                  </span>
                  <div className="p-2.5 rounded-lg bg-slate-50 font-mono text-slate-800 text-[11px] border border-slate-100 leading-relaxed">
                    {selectedStandard.bookExample.reference}
                  </div>
                </div>
              </div>
            </div>

            {/* Journal Article Citation Example */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 space-y-4 shadow-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
                  <FileText className="w-4 h-4 text-[#2e7097]" />
                  <span>{isAr ? 'نموذج توثيق دورية علمية (Journal Article)' : 'Journal Citation Example'}</span>
                </div>
                <button
                  onClick={() => handleCopy(selectedStandard.journalExample.reference, 'journal')}
                  className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-[#2e7097] transition-colors px-2 py-1 rounded bg-slate-50 hover:bg-[#f0f7f4] cursor-pointer"
                  title="نسخ صيغة المرجع"
                >
                  {copiedKey === 'journal' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-600 font-semibold">{isAr ? 'تم النسخ!' : 'Copied!'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>{isAr ? 'نسخ المرجع' : 'Copy'}</span>
                    </>
                  )}
                </button>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-slate-400 font-semibold block mb-0.5">
                    {isAr ? 'التوثيق في المتن (In-Text Citation):' : 'In-Text Citation:'}
                  </span>
                  <div className="p-2.5 rounded-lg bg-slate-50 font-mono text-slate-800 text-[11px] border border-slate-100">
                    {selectedStandard.journalExample.inText}
                  </div>
                </div>

                <div>
                  <span className="text-slate-400 font-semibold block mb-0.5">
                    {isAr ? 'قائمة المراجع النهائية (Reference List):' : 'Reference List Entry:'}
                  </span>
                  <div className="p-2.5 rounded-lg bg-slate-50 font-mono text-slate-800 text-[11px] border border-slate-100 leading-relaxed">
                    {selectedStandard.journalExample.reference}
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Key University Rules */}
          <div className="bg-[#f0f7f4] rounded-xl p-4 border border-[#2e7097]/20">
            <h4 className="text-xs font-bold text-[#193f59] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-[#2e7097]" />
              <span>{isAr ? 'قواعد جوهرية يلتزم بها فريق التدقيق في أورا للأفكار:' : 'Key Rigor Guidelines Enforced by Aura Ideas:'}</span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {selectedStandard.keyRules.map((rule, idx) => (
                <div key={idx} className="flex items-start gap-2 text-xs text-slate-700 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#61ce70] mt-1.5 shrink-0"></span>
                  <span>{rule}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
