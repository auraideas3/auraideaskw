import React from 'react';
import { 
  Compass, 
  ShieldCheck, 
  Target, 
  Cpu, 
  Check, 
  X, 
  HelpCircle,
  Lightbulb,
  BookOpen
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface AboutStoryProps {
  lang: Language;
}

export const AboutStory: React.FC<AboutStoryProps> = ({ lang }) => {
  const t = contentData[lang].aboutStory;
  const isAr = lang === 'ar';

  const pillarIcons = [Compass, ShieldCheck, Target, Cpu];

  return (
    <section id="about" className="bg-white border-b border-slate-200/80">
      {/* Official About Page Header from aura-ideas.com/about/ */}
      <header className="aura-about-hero">
        <div className="aura-about-kicker">
          <i></i>
          <span>{isAr ? 'نبني الوضوح من الفكرة' : 'Building clarity from the idea'}</span>
        </div>
        <h1>{isAr ? 'من نحن' : 'About Us'}</h1>
        <p>
          {isAr 
            ? 'أورا للأفكار مساحة تساعد الطلاب والباحثين على تنظيم العمل الأكاديمي وتحويل الفكرة إلى خطوات واضحة ومحتوى منسق.' 
            : 'Aura Ideas is a dedicated academic space helping students and researchers organize scholarly work, transforming ideas into clear actionable milestones and structured content.'}
        </p>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Narrative & Distinctive Philosophy */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          
          <div className="lg:col-span-7 space-y-5 text-slate-700 leading-relaxed text-base sm:text-lg">
            <p className="font-medium text-slate-900 leading-relaxed">
              {t.p1}
            </p>
            <p className="text-slate-600">
              {t.p2}
            </p>
            <div className="p-4 rounded-xl bg-[#f0f7f4] border-r-4 border-[#61ce70] text-[#193f59] text-sm sm:text-base italic font-medium">
              "{t.p3}"
            </div>
          </div>

          {/* Contrast Box: The Aura Ideas Distinction */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl bg-[#0e2433] text-white p-6 sm:p-7 shadow-xl border border-[#2e7097]/40 space-y-5">
              <div className="flex items-center gap-2 text-[#86efac] font-bold text-sm">
                <BookOpen className="w-5 h-5 text-[#61ce70]" />
                <span>{isAr ? 'الفارق بين أورا للمشورة والخدمات التجارية' : 'The Aura Ideas Paradigm vs Commercial Mills'}</span>
              </div>

              <div className="space-y-3 text-xs sm:text-sm">
                <div className="p-3 rounded-xl bg-[#143247]/80 border border-[#2e7097]/30 flex items-start gap-2.5">
                  <span className="text-[#86efac] p-0.5 rounded bg-[#61ce70]/20 shrink-0 mt-0.5">
                    <Check className="w-4 h-4" />
                  </span>
                  <div>
                    <span className="font-bold text-white">{isAr ? 'أورا للأفكار (توجيه علمي): ' : 'Aura Ideas (Mentoring): '}</span>
                    <span className="text-slate-200 leading-relaxed">
                      {isAr ? 'جلسات إرشادية، وشرح للنتائج الإحصائية، وإعداد للباحث للدفاع عن أطروحته أمام اللجنة بتمكن.' : '1-on-1 coaching, empirical clarity, and thorough viva defense preparation.'}
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-red-950/30 border border-red-900/40 flex items-start gap-2.5 text-slate-300">
                  <span className="text-red-400 p-0.5 rounded bg-red-500/20 shrink-0 mt-0.5">
                    <X className="w-4 h-4" />
                  </span>
                  <div>
                    <span className="font-bold text-red-200">{isAr ? 'المكاتب العشوائية: ' : 'Commercial Mills: '}</span>
                    <span className="text-slate-400">
                      {isAr ? 'تسليم أوراق مجهولة المصدر دون شرح أو متابعة، مما يعرض الطالب للحرج والرسوب أثناء المناقشة.' : 'Opaque text dumping without student comprehension, risking harsh failure in the viva.'}
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#143247]/80 border border-[#2e7097]/30 flex items-start gap-2.5">
                  <span className="text-[#86efac] p-0.5 rounded bg-[#61ce70]/20 shrink-0 mt-0.5">
                    <Check className="w-4 h-4" />
                  </span>
                  <div>
                    <span className="font-bold text-white">{isAr ? 'أورا للأفكار (الالتزام باللائحة): ' : 'Aura Ideas (Full Compliance): '}</span>
                    <span className="text-slate-200 leading-relaxed">
                      {isAr ? 'تطبيق دقيق لدليل كتابة الرسائل لجامعة الكويت، AUM، GUST، والجامعات الإقليمية.' : 'Exact adherence to faculty styling, IRB ethics, and formatting bylaws.'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* 4 Foundational Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {t.pillars.map((pillar, idx) => {
            const Icon = pillarIcons[idx] || Compass;
            return (
              <div 
                key={idx}
                className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:bg-[#f0f7f4] hover:border-[#61ce70]/50 hover:shadow-md transition-all duration-300 group"
              >
                <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 text-[#2e7097] flex items-center justify-center mb-4 shadow-xs group-hover:scale-105 group-hover:bg-[#2e7097] group-hover:text-white transition-all">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-[#193f59] mb-2 font-display">
                  {pillar.title}
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {pillar.desc}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
