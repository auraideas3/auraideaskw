import React, { useState } from 'react';
import { 
  Shield, 
  Lock, 
  CheckCircle2, 
  Clock, 
  Check, 
  Target, 
  Eye, 
  Sparkles,
  ArrowRight,
  ArrowLeft
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface VisionMissionValuesProps {
  lang: Language;
}

export const VisionMissionValues: React.FC<VisionMissionValuesProps> = ({ lang }) => {
  const t = contentData[lang].visionMission;
  const isAr = lang === 'ar';
  const [activeValueId, setActiveValueId] = useState<string>(t.values[0].id);

  const valueIcons: Record<string, React.ReactNode> = {
    integrity: <Shield className="w-5 h-5" />,
    confidentiality: <Lock className="w-5 h-5" />,
    precision: <CheckCircle2 className="w-5 h-5" />,
    commitment: <Clock className="w-5 h-5" />,
  };

  const selectedValue = t.values.find(v => v.id === activeValueId) || t.values[0];

  return (
    <section id="vision-mission" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eaf7ed] border border-[#61ce70]/30 text-[#193f59] text-xs font-bold tracking-wide">
            <Target className="w-3.5 h-3.5 text-[#2e7097]" />
            <span>{t.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#193f59] font-display">
            {t.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.subtitle}
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#2e7097] to-[#61ce70] mx-auto rounded-full mt-4"></div>
        </div>

        {/* Vision & Mission Dual Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          
          {/* Vision Card */}
          <div className="relative rounded-2xl bg-white p-8 border border-slate-200/80 shadow-xs hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-[#eaf7ed] text-[#2e7097] flex items-center justify-center mb-5 border border-[#2e7097]/20">
              <Eye className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-[#193f59] mb-3 font-display">
              {t.visionTitle}
            </h3>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              {t.visionDesc}
            </p>
          </div>

          {/* Mission Card */}
          <div className="relative rounded-2xl bg-white p-8 border border-slate-200/80 shadow-xs hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-[#f0f7f4] text-[#15803d] flex items-center justify-center mb-5 border border-[#61ce70]/30">
              <Target className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-[#193f59] mb-3 font-display">
              {t.missionTitle}
            </h3>
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              {t.missionDesc}
            </p>
          </div>

        </div>

        {/* Interactive Values Section */}
        <div id="values" className="mt-12">
          <div className="text-center max-w-xl mx-auto mb-8">
            <h3 className="text-2xl font-bold text-[#193f59] font-display">
              {isAr ? 'القيم الأربعة الرصينة في أورا' : 'The Four Non-Negotiable Core Values'}
            </h3>
            <p className="text-sm text-slate-500 mt-1">
              {isAr ? 'اضغط على أي قيمة لاستعراض بنود التزامنا الأكاديمي بها' : 'Select a value to explore our specific academic commitments'}
            </p>
          </div>

          {/* Value Tabs Selector */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
            {t.values.map((val) => {
              const isSelected = val.id === activeValueId;
              return (
                <button
                  key={val.id}
                  onClick={() => setActiveValueId(val.id)}
                  className={`p-4 rounded-xl text-start transition-all duration-200 flex flex-col justify-between border cursor-pointer ${
                    isSelected 
                      ? 'bg-[#193f59] text-white border-[#193f59] shadow-lg scale-[1.02]' 
                      : 'bg-white text-slate-700 border-slate-200 hover:border-[#2e7097]/40 hover:bg-[#f0f7f4]'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-2">
                    <span className={`p-2 rounded-lg ${isSelected ? 'bg-[#61ce70]/20 text-[#86efac]' : 'bg-slate-100 text-[#2e7097]'}`}>
                      {valueIcons[val.id]}
                    </span>
                    {isSelected && (
                      <span className="w-2 h-2 rounded-full bg-[#61ce70] animate-pulse"></span>
                    )}
                  </div>
                  <div>
                    <h4 className="font-bold text-sm sm:text-base leading-tight font-display">
                      {val.title}
                    </h4>
                    <span className={`text-[11px] block mt-0.5 ${isSelected ? 'text-[#86efac]' : 'text-slate-400'}`}>
                      {val.subtitle}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected Value Deep Dive Card */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs transition-all duration-300">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              <div className="lg:col-span-7 space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#eaf7ed] text-[#193f59] text-xs font-bold border border-[#61ce70]/30">
                  {valueIcons[selectedValue.id]}
                  <span>{selectedValue.title} — {selectedValue.subtitle}</span>
                </div>
                <p className="text-base sm:text-lg text-slate-700 leading-relaxed">
                  {selectedValue.description}
                </p>
                
                <div className="space-y-2 pt-2">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    {isAr ? 'ضمانات التنفيذ في أورا للأفكار:' : 'Actionable Guarantees at Aura Ideas:'}
                  </h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {selectedValue.points.map((point, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-slate-800 font-medium">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>{point}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="lg:col-span-5 bg-[#f0f7f4] rounded-xl p-5 border border-[#2e7097]/20 space-y-3">
                <h5 className="text-xs font-bold text-[#193f59] uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#2e7097]" />
                  <span>{isAr ? 'تأثير هذا المعيار على قبول بحثك' : 'Impact on Your Thesis Acceptance'}</span>
                </h5>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {selectedValue.id === 'integrity' && (
                    isAr 
                      ? 'يضمن لك راحة البال التامة أمام برامج فحص الجامعات، ويحميك نهائياً من أي تهمة بالسرقة الأدبية أو الاستلال غير المصرح به.'
                      : 'Ensures absolute peace of mind during faculty originality screening, shielding you from academic misconduct allegations.'
                  )}
                  {selectedValue.id === 'confidentiality' && (
                    isAr 
                      ? 'يحمي أفكارك الإبداعية وبياناتك الميدانية من أي تسريب، مما يحفظ حقك الأصيل كباحث منفرد للعمل.'
                      : 'Protects your innovative hypotheses and proprietary empirical data under strict legal privacy.'
                  )}
                  {selectedValue.id === 'precision' && (
                    isAr 
                      ? 'يقلل ملاحظات المشرف الجامعي إلى الحد الأدنى، لأن العمل يأتي مصاغاً وموثقاً وفق دليل الكلية حرفياً.'
                      : 'Reduces supervisory critique to the bare minimum by complying rigorously with official faculty author guidelines.'
                  )}
                  {selectedValue.id === 'commitment' && (
                    isAr 
                      ? 'يتيح لك وقتاً كافياً للتدرب والاستعداد للمناقشة العلنية دون أي توتر أو مفاجآت في اللحظات الأخيرة.'
                      : 'Provides ample runway for supervisor consultation and thorough defense readiness with zero last-minute panic.'
                  )}
                </p>

                <div className="pt-2 border-t border-[#2e7097]/20 flex items-center justify-between text-xs text-[#2e7097] font-semibold">
                  <span>{isAr ? 'ضمان بنسبة 100%' : '100% Guaranteed Protocol'}</span>
                  <span>{isAr ? 'مستشار دكتوراه متخصص' : 'Supervised by Doctoral Mentor'}</span>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
