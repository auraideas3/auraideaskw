import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Search, 
  CheckCircle2, 
  FileCheck2, 
  Sparkles, 
  AlertCircle, 
  BarChart, 
  BookOpen, 
  RefreshCw,
  Award,
  Layers
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface QualitySimulatorProps {
  lang: Language;
}

export const QualitySimulator: React.FC<QualitySimulatorProps> = ({ lang }) => {
  const t = contentData[lang].qualitySimulator;
  const isAr = lang === 'ar';

  const [activeTab, setActiveTab] = useState<'plagiarism' | 'methodology' | 'references' | 'aiDetection'>('plagiarism');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanCompleted, setScanCompleted] = useState<boolean>(true);

  const handleSimulateScan = () => {
    setIsScanning(true);
    setScanCompleted(false);
    setTimeout(() => {
      setIsScanning(false);
      setScanCompleted(true);
    }, 1200);
  };

  return (
    <section id="quality-check" className="py-20 bg-[#0e2433] text-white relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 -right-48 w-96 h-96 bg-[#2e7097]/20 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute top-1/2 -left-48 w-96 h-96 bg-[#61ce70]/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#61ce70]/15 text-[#86efac] text-xs font-bold tracking-wide border border-[#61ce70]/30">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{t.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
            {t.title}
          </h2>
          <p className="text-base text-slate-300">
            {t.subtitle}
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#2e7097] to-[#61ce70] mx-auto rounded-full mt-4"></div>
        </div>

        {/* Interactive Simulator Shell */}
        <div className="max-w-5xl mx-auto bg-[#143247]/80 rounded-2xl border border-[#2e7097]/40 shadow-2xl overflow-hidden backdrop-blur-sm">
          
          {/* Top Tabs */}
          <div className="grid grid-cols-2 md:grid-cols-4 border-b border-[#2e7097]/30 bg-[#0e2433]/70">
            <button
              onClick={() => setActiveTab('plagiarism')}
              className={`p-4 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'plagiarism'
                  ? 'bg-[#193f59] text-[#86efac] border-b-2 border-[#61ce70]'
                  : 'text-slate-300 hover:text-white hover:bg-[#193f59]/50'
              }`}
            >
              <FileCheck2 className="w-4 h-4" />
              <span>{isAr ? 'فحص الاستلال والأصالة' : 'Originality & Plagiarism Audit'}</span>
            </button>

            <button
              onClick={() => setActiveTab('methodology')}
              className={`p-4 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'methodology'
                  ? 'bg-[#193f59] text-[#86efac] border-b-2 border-[#61ce70]'
                  : 'text-slate-300 hover:text-white hover:bg-[#193f59]/50'
              }`}
            >
              <BarChart className="w-4 h-4" />
              <span>{isAr ? 'الصرامة المنهجية' : 'Methodology Rigor'}</span>
            </button>

            <button
              onClick={() => setActiveTab('references')}
              className={`p-4 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'references'
                  ? 'bg-[#193f59] text-[#86efac] border-b-2 border-[#61ce70]'
                  : 'text-slate-300 hover:text-white hover:bg-[#193f59]/50'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>{isAr ? 'حداثة وتوثيق المراجع' : 'Reference Currency'}</span>
            </button>

            <button
              onClick={() => setActiveTab('aiDetection')}
              className={`p-4 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'aiDetection'
                  ? 'bg-[#193f59] text-[#86efac] border-b-2 border-[#61ce70]'
                  : 'text-slate-300 hover:text-white hover:bg-[#193f59]/50'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>{isAr ? 'التأليف البشري الأكاديمي' : 'Human Authorship'}</span>
            </button>
          </div>

          {/* Tab Content Body */}
          <div className="p-6 sm:p-8">
            
            {/* 1. Plagiarism & Originality Simulator */}
            {activeTab === 'plagiarism' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <FileCheck2 className="w-5 h-5 text-[#61ce70]" />
                      <span>{isAr ? 'محاكاة تقرير فحص الاستلال والأصالة المعتمد' : 'Certified Originality & Similarity Audit Simulation'}</span>
                    </h3>
                    <p className="text-xs text-slate-300 mt-1">
                      {isAr ? 'يتم فحص كل مسودة بحثية ضد 90 مليار صفحة ويب، و 1.8 مليار ورقة طلابية، و 92 مليون مقال علمي محكم.' : 'Every draft is screened against 90B+ web pages, 1.8B student papers, and 92M+ peer-reviewed publications.'}
                    </p>
                  </div>
                  <button
                    onClick={handleSimulateScan}
                    disabled={isScanning}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#61ce70] hover:bg-[#4eb85d] text-[#0e2433] font-bold text-xs shadow-md transition-all cursor-pointer active:scale-95 disabled:opacity-50 self-start sm:self-auto"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                    <span>{isScanning ? (isAr ? 'جاري الفحص المتقاطع...' : 'Cross-checking...') : (isAr ? 'إعادة الفحص المباشر' : 'Re-run Scan')}</span>
                  </button>
                </div>

                {/* Progress bar during scan */}
                {isScanning && (
                  <div className="space-y-2 p-4 rounded-xl bg-[#0e2433]/80 border border-[#2e7097]/40">
                    <div className="flex justify-between text-xs text-[#86efac] font-mono">
                      <span>{isAr ? 'فحص القواعد: Crossref, ProQuest, Shuaa...' : 'Scanning databases: Crossref, ProQuest, Shuaa...'}</span>
                      <span>87%</span>
                    </div>
                    <div className="w-full bg-[#193f59] h-2 rounded-full overflow-hidden">
                      <div className="bg-[#61ce70] h-full w-[87%] animate-pulse"></div>
                    </div>
                  </div>
                )}

                {/* Live Results Card */}
                {scanCompleted && !isScanning && (
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                    
                    {/* Score Dial */}
                    <div className="md:col-span-4 p-5 rounded-xl bg-[#0e2433] border border-[#2e7097]/40 text-center space-y-2">
                      <div className="relative inline-flex items-center justify-center">
                        <div className="w-28 h-28 rounded-full border-4 border-[#61ce70]/40 flex items-center justify-center">
                          <div className="text-center">
                            <span className="text-3xl font-black text-[#86efac] font-mono">2.1%</span>
                            <span className="block text-[10px] text-slate-400 uppercase tracking-widest">{isAr ? 'نسبة الاستلال الكلية' : 'Similarity Index'}</span>
                          </div>
                        </div>
                      </div>
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#61ce70]/20 text-[#86efac] text-xs font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{isAr ? 'مُجاز بامتياز (أقل من 15%)' : 'Approved: Well Below 15%'}</span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        {isAr ? 'النسبة مقتصرة حصراً على المصطلحات وقوانين المعادلات المتعارف عليها.' : 'Similarity is strictly limited to standardized formulaic titles and terminologies.'}
                      </p>
                    </div>

                    {/* Source Breakdown Table */}
                    <div className="md:col-span-8 space-y-3">
                      <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                        {isAr ? 'تفاصيل مطابقة المصادر وفق تقرير أورا:' : 'Source Breakdown in Aura Audit:'}
                      </div>

                      <div className="space-y-2 text-xs">
                        <div className="p-3 rounded-lg bg-[#0e2433]/80 border border-[#2e7097]/30 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full bg-[#61ce70]"></span>
                            <span className="text-slate-200">{isAr ? 'المحتوى الأصلي المؤصل (أقلام نخبة أورا الأكاديمية)' : 'Authentic Scholar Content (Aura Faculty)'}</span>
                          </div>
                          <span className="font-mono font-bold text-[#86efac]">97.9%</span>
                        </div>

                        <div className="p-3 rounded-lg bg-[#0e2433]/80 border border-[#2e7097]/30 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full bg-[#38bdf8]"></span>
                            <span className="text-slate-200">{isAr ? 'نصوص المصطلحات والقوانين الرسمية الموثقة' : 'Standard Statutory & Theoretical Terminologies'}</span>
                          </div>
                          <span className="font-mono font-bold text-[#38bdf8]">1.3%</span>
                        </div>

                        <div className="p-3 rounded-lg bg-[#0e2433]/80 border border-[#2e7097]/30 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full bg-[#86efac]"></span>
                            <span className="text-slate-200">{isAr ? 'بيانات المراجع وعناوين الدوريات الشائعة' : 'Common Journal Titles & Citations'}</span>
                          </div>
                          <span className="font-mono font-bold text-[#86efac]">0.8%</span>
                        </div>
                      </div>

                      <div className="p-3 rounded-lg bg-[#193f59]/60 border border-[#2e7097]/40 text-xs text-[#86efac] flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 shrink-0 text-[#61ce70]" />
                        <span>{isAr ? 'شهادة ضمان استلال رسمية مختومة تسلم للباحث مع كل فصل.' : 'Certified and timestamped originality report delivered to you with every thesis chapter.'}</span>
                      </div>
                    </div>

                  </div>
                )}
              </div>
            )}

            {/* 2. Methodology Rigor Tab */}
            {activeTab === 'methodology' && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <BarChart className="w-5 h-5 text-[#61ce70]" />
                    <span>{isAr ? 'معايير الصرامة المنهجية والتحليل الإحصائي' : 'Methodological Rigor & Empirical Precision'}</span>
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div className="p-4 rounded-xl bg-[#0e2433] border border-[#2e7097]/30 space-y-2">
                    <div className="flex items-center gap-2 text-[#86efac] font-bold">
                      <Layers className="w-4 h-4 text-[#61ce70]" />
                      <span>{isAr ? 'الفجوة البحثية (Research Gap)' : 'Research Gap Delineation'}</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {isAr ? 'صياغة إشكالية واضحة ومبررة علمياً تثبت إضافة البحث للمعرفة وتجيب على سؤال: «ما الجديد الذي يقدمه هذا البحث؟»' : 'Justified problem statement clearly articulating theoretical novelty and empirical contribution.'}
                    </p>
                    <span className="inline-block text-[11px] text-[#86efac] font-bold">{isAr ? 'مستوفى 100%' : '100% Verified'}</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0e2433] border border-[#2e7097]/30 space-y-2">
                    <div className="flex items-center gap-2 text-[#38bdf8] font-bold">
                      <BarChart className="w-4 h-4" />
                      <span>{isAr ? 'قوة العينة (Power Analysis)' : 'Sample Size & G*Power'}</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {isAr ? 'حساب حجم العينة الممثل إحصائياً وتطبيق مقاييس الصدق الظاهري والبنائي والثبات بألفا كرونباخ وتوكيد العامل.' : 'Statistically calculated sample sizes with verified construct validity and Cronbach’s alpha > 0.80.'}
                    </p>
                    <span className="inline-block text-[11px] text-[#86efac] font-bold">{isAr ? 'مستوفى 100%' : '100% Verified'}</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0e2433] border border-[#2e7097]/30 space-y-2">
                    <div className="flex items-center gap-2 text-[#86efac] font-bold">
                      <Award className="w-4 h-4 text-[#61ce70]" />
                      <span>{isAr ? 'اتساق الفروض والنتائج' : 'Hypothesis-Outcome Linkage'}</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {isAr ? 'ربط نتائج التحليل الإحصائي مباشرة بتساؤلات الدراسة وفرضياتها ومقارنتها بنتائج الدراسات السابقة الكويتية والدولية.' : 'Direct linkage between quantitative regression outcomes, research questions, and literature comparison.'}
                    </p>
                    <span className="inline-block text-[11px] text-[#86efac] font-bold">{isAr ? 'مستوفى 100%' : '100% Verified'}</span>
                  </div>
                </div>
              </div>
            )}

            {/* 3. Reference Currency Tab */}
            {activeTab === 'references' && (
              <div className="space-y-5">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-[#38bdf8]" />
                  <span>{isAr ? 'معايير حداثة وفهرسة المراجع الأكاديمية' : 'Source Currency & Indexation Criteria'}</span>
                </h3>

                <div className="p-4 rounded-xl bg-[#0e2433] border border-[#2e7097]/30 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-[#143247] border border-[#2e7097]/30">
                      <span className="text-xs text-slate-300 block">{isAr ? 'نسبة المراجع الحديثة (آخر 3 - 5 سنوات):' : 'Currency Ratio (Last 3-5 Years):'}</span>
                      <span className="text-xl font-bold text-[#86efac] font-mono">88.5%</span>
                      <p className="text-[11px] text-slate-400 mt-1">{isAr ? 'تغطي أحدث إصدارات 2022 - 2025' : 'Focuses heavily on 2022-2025 scholarship'}</p>
                    </div>

                    <div className="p-3 rounded-lg bg-[#143247] border border-[#2e7097]/30">
                      <span className="text-xs text-slate-300 block">{isAr ? 'نسبة المراجع المصنفة في Scopus و Web of Science:' : 'Indexed in Scopus / Web of Science:'}</span>
                      <span className="text-xl font-bold text-[#38bdf8] font-mono">92.0%</span>
                      <p className="text-[11px] text-slate-400 mt-1">{isAr ? 'أوراق علمية محكمة في مجلات Q1 و Q2' : 'Top-quartile peer-reviewed journals'}</p>
                    </div>
                  </div>

                  <div className="text-xs text-slate-300 space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#61ce70]" />
                      <span>{isAr ? 'ربط كل مرجع برابط الـ DOI النشط للتحقق الفوري من قبل مشرفك الجامعي.' : 'Every digital reference includes an active, resolving DOI link for instantaneous supervisory audit.'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#61ce70]" />
                      <span>{isAr ? 'توازن رصين بين المراجع الأجنبية العالمية والدراسات العربية والمحلية الميدانية في دولة الكويت.' : 'Harmonious balance between global international scholarship and localized Kuwait empirical data.'}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 4. Human Authorship Tab */}
            {activeTab === 'aiDetection' && (
              <div className="space-y-5">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#86efac]" />
                  <span>{isAr ? 'ضمان الصياغة البشرية الأكاديمية (خلو تام من الذكاء الاصطناعي المشوه)' : 'Human Scholarly Authorship (Zero Hallucinatory AI Text)'}</span>
                </h3>

                <div className="p-5 rounded-xl bg-[#0e2433] border border-[#2e7097]/30 space-y-4">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-[#143247] border border-[#61ce70]/40">
                    <div className="flex items-center gap-2.5">
                      <CheckCircle2 className="w-5 h-5 text-[#61ce70]" />
                      <div>
                        <span className="text-sm font-bold text-[#86efac]">{isAr ? 'صياغة بشرية 100% بأقلام أساتذة متخصصين' : '100% Human Scholarly Authorship'}</span>
                        <p className="text-xs text-slate-300">{isAr ? 'نصوص رصينة بنَفَس أكاديمي ناقد يمتلك حجة علمية وترابطاً منطقياً.' : 'Nuanced scholarly discourse with critical synthesis that AI generators cannot fabricate.'}</p>
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-[#61ce70]/20 text-[#86efac]">
                      0% AI
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {isAr
                      ? 'الجامعات اليوم تستخدم أدوات صارمة (مثل برامج كشف الذكاء الاصطناعي الأكاديمية المعتمدة و GPTZero) لكشف النصوص المولدة آلياً والتي تتسم بالعموميات والمراجع الوهمية (Hallucinated References). في أورا للأفكار، كل كلمة تُكتب بواسطة باحث دكتوراه متخصص، وتمر على لجنة تدقيق لغوي ومنهجي مستقلة.'
                      : 'Graduate universities now deploy specialized AI detectors to flag superficial, auto-generated filler and fabricated citations. At Aura Ideas, every manuscript is authored by human subject specialists and scrutinized by independent peer reviewers.'
                    }
                  </p>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
