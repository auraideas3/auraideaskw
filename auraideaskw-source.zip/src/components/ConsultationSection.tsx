import React, { useState } from 'react';
import { 
  MessageCircle, 
  Send, 
  Phone, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  CheckCircle, 
  Sparkles,
  Lock,
  GraduationCap
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface ConsultationSectionProps {
  lang: Language;
  prefilledField?: string;
}

export const ConsultationSection: React.FC<ConsultationSectionProps> = ({ lang, prefilledField }) => {
  const t = contentData[lang].contact;
  const isAr = lang === 'ar';

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [university, setUniversity] = useState('');
  const [degree, setDegree] = useState(t.form.degrees[0]);
  const [service, setService] = useState(t.form.services[0]);
  const [notes, setNotes] = useState(prefilledField ? `استفسار بخصوص تخصص: ${prefilledField}` : '');
  const [submitted, setSubmitted] = useState(false);

  // Generate dynamic WhatsApp link
  const buildWhatsAppLink = () => {
    const message = isAr
      ? `مرحباً، أود حجز استشارة أكاديمية في أورا للأفكار:\n- الاسم: ${name || 'غير محدد'}\n- المرحلة: ${degree}\n- الجامعة: ${university || 'الكويت/الخليج'}\n- الخدمة: ${service}\n- ملاحظات: ${notes || 'موضوع جديد'}`
      : `Hello, I would like to request an academic consultation with Aura Ideas:\n- Name: ${name || 'Unspecified'}\n- Degree: ${degree}\n- University: ${university || 'Kuwait/GCC'}\n- Service: ${service}\n- Notes: ${notes || 'New Topic'}`;
    
    return `https://wa.me/971588740073?text=${encodeURIComponent(message)}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eaf7ed] border border-[#61ce70]/30 text-[#193f59] text-xs font-bold tracking-wide">
            <MessageCircle className="w-3.5 h-3.5 text-[#2e7097]" />
            <span>{t.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#193f59] font-display">
            {t.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.subtitle}
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#2e7097] to-[#61ce70] mx-auto rounded-full mt-4"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Contact Direct Info Sidebar */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Direct WhatsApp Callout Card */}
            <div className="rounded-2xl bg-[#0e2433] text-white p-6 sm:p-8 shadow-xl border border-[#2e7097]/40 relative overflow-hidden">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-[#61ce70]/20 text-[#86efac] flex items-center justify-center">
                  <MessageCircle className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold font-display">
                  {t.hotlineTitle}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isAr 
                    ? 'فريق الاستشارات الأكاديمية متاح على مدار الساعة للإجابة عن استفسارات طلبة الماجستير والدكتوراه والرد الفوري عبر واتساب.' 
                    : 'Our senior academic advisory team is available around the clock to assist graduate researchers with immediate WhatsApp response.'
                  }
                </p>

                <a
                  href={buildWhatsAppLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 w-full py-3.5 rounded-xl bg-[#61ce70] hover:bg-[#4eb85d] text-[#0e2433] font-bold text-sm shadow-md transition-all active:scale-95 cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{t.whatsappCta}</span>
                </a>
              </div>
            </div>

            {/* Institutional Credentials Box */}
            <div className="p-6 rounded-2xl bg-[#f0f7f4] border border-[#2e7097]/20 space-y-4">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-white text-[#2e7097] shadow-xs shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#193f59] font-display">
                    {t.officeTitle}
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {t.officeDesc}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 pt-3 border-t border-slate-200/80">
                <div className="p-2 rounded-lg bg-white text-[#2e7097] shadow-xs shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#193f59] font-display">
                    {t.emailTitle}
                  </h4>
                  <a href="mailto:auraideas1@gmail.com" className="text-xs text-[#2e7097] hover:underline font-mono">
                    auraideas1@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 pt-3 border-t border-slate-200/80">
                <div className="p-2 rounded-lg bg-white text-[#15803d] shadow-xs shrink-0">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#193f59] font-display">
                    {isAr ? 'ميثاق حماية الملكية الفكرية (NDA)' : 'Binding Non-Disclosure Agreement'}
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {isAr ? 'عقد سرية قانوني ملزم يضمن عدم استخدام أو نشر مسوداتك إطلاقاً.' : 'Legally binding confidentiality ensuring your draft is never recycled or shared.'}
                  </p>
                </div>
              </div>
            </div>

          </div>

          {/* Interactive Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-white border border-slate-200 p-6 sm:p-8 shadow-xs">
              <h3 className="text-xl font-bold text-[#193f59] mb-1 font-display">
                {t.form.title}
              </h3>
              <p className="text-xs text-slate-500 mb-6">
                {isAr ? 'سيتم تحويل طلبك مباشرة إلى المشرف المتخصص في مجالك الأكاديمي.' : 'Your request will be routed directly to the doctoral specialist in your discipline.'}
              </p>

              {submitted ? (
                <div className="p-8 rounded-xl bg-[#eaf7ed] border border-[#61ce70]/40 text-center space-y-4">
                  <div className="w-14 h-14 rounded-full bg-[#61ce70]/20 text-[#15803d] flex items-center justify-center mx-auto">
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <h4 className="text-lg font-bold text-[#193f59] font-display">
                    {isAr ? 'تم استلام طلب الاستشارة بنجاح!' : 'Consultation Request Received!'}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-700 max-w-md mx-auto leading-relaxed">
                    {isAr 
                      ? 'شكراً لك. سيتواصل معك أحد مستشاري أورا للأفكار المتخصصين خلال دقائق عبر الواتساب أو الهاتف لمناقشة تفاصيل بحثك.' 
                      : 'Thank you. A specialized doctoral consultant from Aura Ideas will reach out via WhatsApp/phone within minutes.'
                    }
                  </p>
                  
                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <a
                      href={buildWhatsAppLink()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#61ce70] hover:bg-[#4eb85d] text-[#0e2433] font-bold text-xs shadow-xs cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>{isAr ? 'متابعة فورية عبر واتساب الآن' : 'Continue on WhatsApp Now'}</span>
                    </a>
                    <button
                      onClick={() => setSubmitted(false)}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                    >
                      {isAr ? 'إرسال طلب جديد' : 'Submit Another Request'}
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        {t.form.nameLabel} *
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder={t.form.namePlaceholder}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50/50 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        {t.form.phoneLabel} *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder={t.form.phonePlaceholder}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50/50 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        {t.form.degreeLabel}
                      </label>
                      <select
                        value={degree}
                        onChange={(e) => setDegree(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50/50 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                      >
                        {t.form.degrees.map((deg, idx) => (
                          <option key={idx} value={deg}>{deg}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        {t.form.universityLabel}
                      </label>
                      <input
                        type="text"
                        value={university}
                        onChange={(e) => setUniversity(e.target.value)}
                        placeholder={t.form.universityPlaceholder}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50/50 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {t.form.serviceLabel}
                    </label>
                    <select
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50/50 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                    >
                      {t.form.services.map((srv, idx) => (
                        <option key={idx} value={srv}>{srv}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {t.form.notesLabel}
                    </label>
                    <textarea
                      rows={3}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder={t.form.notesPlaceholder}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50/50 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#2e7097]/40 focus:border-[#2e7097]"
                    ></textarea>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#193f59] to-[#2e7097] hover:from-[#0e2433] hover:to-[#193f59] text-white font-bold text-sm sm:text-base shadow-md shadow-[#193f59]/20 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                    >
                      <Send className="w-4 h-4 text-[#86efac]" />
                      <span>{t.form.submitBtn}</span>
                    </button>
                  </div>

                  <div className="flex items-center justify-center gap-2 text-slate-500 text-[11px] pt-1">
                    <Lock className="w-3.5 h-3.5 text-[#2e7097]" />
                    <span>{t.form.secureNote}</span>
                  </div>

                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
