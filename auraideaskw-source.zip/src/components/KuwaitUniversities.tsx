import React from 'react';
import { 
  Building2, 
  CheckCircle, 
  MapPin, 
  Award, 
  ExternalLink,
  GraduationCap
} from 'lucide-react';
import { Language } from '../types';
import { contentData } from '../data/content';

interface KuwaitUniversitiesProps {
  lang: Language;
}

export const KuwaitUniversities: React.FC<KuwaitUniversitiesProps> = ({ lang }) => {
  const t = contentData[lang].universities;
  const isAr = lang === 'ar';

  return (
    <section id="universities" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eaf7ed] border border-[#61ce70]/30 text-[#193f59] text-xs font-bold tracking-wide">
            <Building2 className="w-3.5 h-3.5 text-[#2e7097]" />
            <span>{t.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#193f59] font-display">
            {t.title}
          </h2>
          <p className="text-base text-slate-600">
            {t.subtitle}
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-[#2e7097] to-[#61ce70] mx-auto rounded-full mt-4"></div>
        </div>

        {/* University Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {t.list.map((uni, idx) => (
            <div 
              key={idx}
              className="p-6 rounded-2xl bg-[#f0f7f4]/40 border border-slate-200/80 hover:border-[#61ce70] hover:shadow-md transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-white border border-[#2e7097]/20 text-[#2e7097] flex items-center justify-center shadow-xs">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-semibold text-slate-400">
                    {uni.category}
                  </span>
                </div>

                <h3 className="text-base font-bold text-[#193f59] mb-1.5 font-display">
                  {uni.name}
                </h3>
                
                <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-4">
                  <MapPin className="w-3.5 h-3.5 text-[#2e7097]" />
                  <span>{uni.location}</span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200/80 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-[#15803d] shrink-0" />
                <span className="text-xs font-semibold text-slate-700">
                  {uni.badge}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner Note */}
        <div className="mt-12 p-5 rounded-xl bg-[#eaf7ed] border border-[#61ce70]/40 text-center max-w-3xl mx-auto">
          <p className="text-xs sm:text-sm text-[#0e2433] font-medium leading-relaxed">
            {isAr 
              ? '📌 هل تدرس في جامعة أخرى داخل الخليج أو مبتعث في الخارج؟ فريقنا الاستشاري مؤهل لدراسة دليل كتابة الرسائل الخاص بجامعتك وتطبيق شروطه بدقة متناهية.'
              : '📌 Studying at another regional or overseas university? Our academic advisory council reviews your specific institutional guidelines to guarantee 100% compliance.'
            }
          </p>
        </div>

      </div>
    </section>
  );
};
